<?php

if ((!defined('ABS_PATH')))
    exit('ABS_PATH is not loaded. Direct access is not allowed.');

if (!OC_ADMIN)
    exit('User access is not allowed.');
/*
 * Copyright (C) 2019 Puiu Calin
 * This program is a commercial software: is forbidden to use this software without licence, 
 * on multiple installations, and by purchasing from other source than those authorized for the sale of software.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Single Domain License non-transferable only to use in one domain. 
 * For multiple domains usage is required to purchase the product multiple times.
 */

require_once 'include/utils.php';

$request = Params::getParam('request');
cbk_password_admin_menu_load();
echo '<div class="content-center">';
switch ($request) {
    case('settings_post'):
        osc_set_preference('use_cbk_password', Params::getParam('use_cbk_password'), 'cbk_password');
        osc_set_preference('password_min_char', Params::getParam('password_min_char'), 'cbk_password');
        osc_set_preference('special', Params::getParam('special'), 'cbk_password');
        osc_set_preference('number', Params::getParam('number'), 'cbk_password');
        osc_set_preference('uppercase', Params::getParam('uppercase'), 'cbk_password');
        osc_add_flash_ok_message(__('Settings saved successfully', 'cbk_password'), 'admin');
        header("Location:" . osc_get_http_referer());
        break;
    default:
        require_once 'pages/settings.php';
        break;
}
echo '</div>';
