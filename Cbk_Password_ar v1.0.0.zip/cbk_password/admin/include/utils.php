<?php

if ((!defined('ABS_PATH')))
    exit('ABS_PATH is not loaded. Direct access is not allowed.');
/*
 * Copyright (C) 2019 Puiu Calin
 * This program is a commercial software: is forbidden to use this software without licence, 
 * on multiple installations, and by purchasing from other source than those authorized for the sale of software.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Single Domain License non-transferable only to use in one domain. 
 * For multiple domains usage is required to purchase the product multiple times.
 */


/*
 * Admin menu
 */

function cbk_password_menu_links() {
    $array['main'] = array(
        'title' => __('Settings', 'cbk_password'),
        'icon' => 'fa fa-cog',
        'text' => __('Settings', 'cbk_password'),
        'class' => 'link'
    );

    return $array;
}

function cbk_password_admin_menu_load() {
    $links = cbk_password_menu_links();
    $request = Params::getParam('request') ? Params::getParam('request') : 'main';
    echo '<div class="menu">';
    echo'<div class="title">';
    echo isset($links[$request]['title']) ? $links[$request]['title'] : __('Cbk Password');
    echo'</div>';
    echo '<div class="links">';
    foreach ($links as $key => $value) {
        $active = ($key == $request) ? 'active' : '';
        echo '<a class="' . $value['class'] . ' ' . $active . '" href="' . cbk_password_admin_url($key) . '"><i class="' . $value['icon'] . '"></i>' . $value['text'] . '</a>';
    }
    echo '</div>';
    echo '</div>';
}

function cbk_password_admin_url($request) {
    if (is_array($request)) {
        $params = '';
        foreach ($request as $k => $v) {
            $params .= '&' . $k . '=' . $v;
        }
        $data = $params;
    } else {
        $data = '&request=' . $request;
    }

    return osc_admin_render_plugin_url('cbk_password/admin/base.php') . $data;
}
