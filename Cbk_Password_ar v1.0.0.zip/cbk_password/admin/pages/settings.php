<?php
if ((!defined('ABS_PATH')))
    exit('ABS_PATH is not loaded. Direct access is not allowed.');

if (!OC_ADMIN)
    exit('User access is not allowed.');
/*
 * Copyright (C) 2019 Puiu Calin
 * This program is a commercial software: is forbidden to use this software without licence, 
 * on multiple installations, and by purchasing from other source than those authorized for the sale of software.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Single Domain License non-transferable only to use in one domain. 
 * For multiple domains usage is required to purchase the product multiple times.
 */
?>
<div class="block-content">
    <div class="block-title">
        <?php _e('Settings', 'cbk_password'); ?>
    </div>
    <form id="subscribe_action" name="subscribe_action" action="<?php echo cbk_password_admin_url('settings_post'); ?>" method="post">
        <div class="f-block">
            <div class="f-label">
                <?php _e('Use', 'cbk_password'); ?>
            </div>
            <div class="f-input">
                <label class="checkbox-modern">
                    <input type="checkbox" name="use_cbk_password" value="1" <?php if (osc_get_preference('use_cbk_password', 'cbk_password') == 1) { ?>checked="checked"<?php } ?>>
                    <span class="c-checkmark"></span>
                    <?php _e('Strong password', 'cbk_password'); ?>
                </label>
                <div class="f-help">
                    <?php _e('Don\'t allow users to use a weak password on register and reset password.', 'cbk_password'); ?>
                </div>
            </div>
        </div>
        <div class="f-block">
            <div class="f-label">
                <?php _e('Min. characters', 'cbk_password'); ?>
            </div>
            <div class="f-input">
                <input type="text" name="password_min_char" value="<?php echo osc_esc_html(osc_get_preference('password_min_char', 'cbk_password')); ?>" />
            </div> 
        </div>
        <div class="f-block">
            <div class="f-label">
                <?php _e('Special characters', 'cbk_password'); ?>
            </div>
            <div class="f-input">
                <label class="checkbox-modern">
                    <input type="checkbox" name="special" value="1" <?php if (osc_get_preference('special', 'cbk_password') == 1) { ?>checked="checked"<?php } ?>>
                    <span class="c-checkmark"></span>
                    <?php _e('Use at least one special character', 'cbk_password'); ?>
                </label>
            </div>
        </div>
        <div class="f-block">
            <div class="f-label">
                <?php _e('Number', 'cbk_password'); ?>
            </div>
            <div class="f-input">
                <label class="checkbox-modern">
                    <input type="checkbox" name="number" value="1" <?php if (osc_get_preference('number', 'cbk_password') == 1) { ?>checked="checked"<?php } ?>>
                    <span class="c-checkmark"></span>
                    <?php _e('Use at least one number', 'cbk_password'); ?>
                </label>
            </div>
        </div>
        <div class="f-block">
            <div class="f-label">
                <?php _e('Uppercase', 'cbk_password'); ?>
            </div>
            <div class="f-input">
                <label class="checkbox-modern">
                    <input type="checkbox" name="uppercase" value="1" <?php if (osc_get_preference('uppercase', 'cbk_password') == 1) { ?>checked="checked"<?php } ?>>
                    <span class="c-checkmark"></span>
                    <?php _e('Use at least one uppercase', 'cbk_password'); ?>
                </label>
            </div>
        </div>
        <div class="f-block">
            <div class="f-label">
                <button type="submit"><?php _e('Save', 'cbk_password'); ?></button>
            </div>
        </div>
    </form>
    <div class="block-title">
        <?php _e('Help', 'cbk_password'); ?>
    </div>
    <p><?php _e('These options are available on the register page and change password page. The check is made before the form is submitted and you have multiple options to force your user to set a strong password.', 'cbk_password'); ?></p>
    <p><?php _e('If the password will not meet the parameters the user cannot create the account or reset the password.', 'cbk_password'); ?></p>
</div>
<?php if (CBK_PASSWORD_RIGHTS) { ?>
    <div class="cbk_author">
        <div class="autor_calinbehtuk">
            <span class="p_ro"></span><span>osclassCalinbehtuk</span> &#9400; 
            <?php echo date("Y"); ?> 
            <?php _e('All rights reserved', 'cbk_password'); ?>
            | <a target="_blank" href="https://osclass.calinbehtuk.ro/contact"><?php _e('Contact', 'cbk_password'); ?></a>
            <div class="fb-like" data-href="https://www.facebook.com/OsclassMarket-2038630222819201/" data-layout="standard" data-action="like" data-size="small" data-show-faces="false" data-share="false"></div>
        </div>
        <div id="fb-root"></div>
        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.12&appId=390212651179613&autoLogAppEvents=1';
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script>
    </div>
<?php } ?>