<?php
/*
 * Copyright (C) 2019 Puiu Calin
 * This program is a commercial software: is forbidden to use this software without licence, 
 * on multiple installations, and by purchasing from other source than those authorized for the sale of software.
 * Unauthorized copying of this file, via any medium is strictly prohibited
 */

class CbkAuthorClass {

    private $pluginUrl;
    private $Url;
    private $market = 1;

    function __construct() {
        $this->pluginUrl = osc_base_url() . 'oc-content/plugins/cbk_password/include/CbkAuthor/';
        $this->Url = 'https://osclass.calinbehtuk.ro/';
    }

    public function init() {
        if ($this->market) {
            osc_add_hook('admin_footer', array($this, 'adminFooter'));
        }
    }

    public function adminFooter() {
        $page = Params::getParam('page');
        if (empty($page)) {
            ?>
            <script type="text/javascript">
                $(document).ready(function () {
                    $("#banner_market").parent().addClass('new-market-class');
                    $('.new-market-class').html(favicon_m_banner());
                    products_m();
                });

                function favicon_m_banner() {
                    var url = '<?php echo $this->bannerImageLink(); ?>';
                    var banner = '<a href="<?php echo $this->bannerLink(); ?>" target="_blank"><div style="height: 100%; width: 100%;background: url(' + url + ') no-repeat;"></div></a>';
                    return banner;
                }

                function products_m() {
                    $('.widget-box-project .widget-box-content').html('');
                    var url = '<?php echo $this->productImageLink(); ?>';
                    $('.widget-box-project .widget-box-content').append('<a  target="_blank" href="<?php echo $this->productLink(); ?>" class="mk-item-parent  is-featured" data-type="theme"><div class="mk-item mk-item-theme"><div style="background-image:url(' + url + '); height:100%;"></div></div></a>');
                }

            </script>
            <?php
        }
    }

    public function bannerImageLink() {
        return $this->pluginUrl . 'images/get.png';
    }

    public function productImageLink() {
        return $this->pluginUrl . 'images/theme-1.jpg';
    }

    public function bannerLink() {
        return $this->Url . 'plugins';
    }

    public function productLink() {
        return $this->Url . 'themes/general/cbk-osclass-premium-theme_i36';
    }

}
