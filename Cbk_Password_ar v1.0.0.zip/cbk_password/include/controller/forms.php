<?php

if ((!defined('ABS_PATH')))
    exit('ABS_PATH is not loaded. Direct access is not allowed.');
/*
 * Copyright (C) 2019 Puiu Calin
 * This program is a commercial software: is forbidden to use this software without licence, 
 * on multiple installations, and by purchasing from other source than those authorized for the sale of software.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Single Domain License non-transferable only to use in one domain. 
 * For multiple domains usage is required to purchase the product multiple times.
 */

function cbk_password_before_register() {
    $password = Params::getParam('s_password');
    $limitChar = 5;
    $savedLimitChar = osc_get_preference('password_min_char', 'cbk_password');
    if (is_numeric($savedLimitChar)) {
        $limitChar = $savedLimitChar;
    }
    $error = '';

    //count string length
    $length = strlen($password);
    if ($length < $limitChar) {
        $error .= sprintf(__('Your passwords need to be at least %s characters', 'cbk_password'), $limitChar) . PHP_EOL;
    }

    //special character
    $special = osc_get_preference('special', 'cbk_password');
    if ($special == 1) {
        if (!preg_match('/[^a-zA-Z\d]/', $password)) {
            $error .= __('Use at least one special character in your password. Like: #$%@& etc.', 'cbk_password') . PHP_EOL;
        }
    }

    //number in password
    $number = osc_get_preference('number', 'cbk_password');
    if ($number == 1) {
        if (!preg_match('/[0-9]/', $password)) {
            $error .= __('Use at least one number in your password', 'cbk_password') . PHP_EOL;
        }
    }

    //uppercase
    $uppercase = osc_get_preference('uppercase', 'cbk_password');
    if ($uppercase == 1) {
        if (!preg_match('/[A-Z]/', $password)) {
            $error .= __('Use at least one uppercase in your password', 'cbk_password') . PHP_EOL;
        }
    }

    if ($error) {
        osc_add_flash_error_message($error);
        header("Location: " . osc_register_account_url());
        exit();
    }
}

//register
$use_plugin = osc_get_preference('use_cbk_password', 'cbk_password');
if ($use_plugin == 1 && !OC_ADMIN) {
    osc_add_hook('before_user_register', 'cbk_password_before_register');
}

//recover

function cbk_password_recover() {
    $action = Params::getParam('action');
    switch ($action) {
        case('forgot_post'):
            $password = Params::getParam('new_password');
            $limitChar = 5;
            $savedLimitChar = osc_get_preference('password_min_char', 'cbk_password');
            if (is_numeric($savedLimitChar)) {
                $limitChar = $savedLimitChar;
            }
            $error = '';

            //count string length
            $length = strlen($password);
            if ($length < $limitChar) {
                $error .= sprintf(__('Your passwords need to be at least %s characters', 'cbk_password'), $limitChar) . PHP_EOL;
            }

            //special character
            $special = osc_get_preference('special', 'cbk_password');
            if ($special == 1) {
                if (!preg_match('/[^a-zA-Z\d]/', $password)) {
                    $error .= __('Use at least one special character in your password. Like: #$%@& etc.', 'cbk_password') . PHP_EOL;
                }
            }

            //number in password
            $number = osc_get_preference('number', 'cbk_password');
            if ($number == 1) {
                if (!preg_match('/[0-9]/', $password)) {
                    $error .= __('Use at least one number in your password', 'cbk_password') . PHP_EOL;
                }
            }

            //uppercase
            $uppercase = osc_get_preference('uppercase', 'cbk_password');
            if ($uppercase == 1) {
                if (!preg_match('/[A-Z]/', $password)) {
                    $error .= __('Use at least one uppercase in your password', 'cbk_password') . PHP_EOL;
                }
            }

            if ($error) {
                osc_add_flash_error_message($error);
                header("Location: " . osc_forgot_user_password_confirm_url(Params::getParam('userId'), Params::getParam('code')));
                exit();
            }
            break;
    }
    
}

if ($use_plugin == 1 && !OC_ADMIN) {
    osc_add_hook('init_login', 'cbk_password_recover');
}