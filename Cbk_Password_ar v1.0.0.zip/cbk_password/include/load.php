<?php

if ((!defined('ABS_PATH')))
    exit('ABS_PATH is not loaded. Direct access is not allowed.');
/*
 * Copyright (C) 2019 Puiu Calin
 * This program is a commercial software: is forbidden to use this software without licence, 
 * on multiple installations, and by purchasing from other source than those authorized for the sale of software.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Single Domain License non-transferable only to use in one domain. 
 * For multiple domains usage is required to purchase the product multiple times.
 */


require_once 'controller/forms.php';

/*
 * Add admin link
 */

function cbk_password_admin_menu() {
    osc_admin_menu_plugins(__('Cbk Password', 'cbk_password'), osc_admin_render_plugin_url('cbk_password/admin/base.php'), 'cbk_password');
}

osc_add_hook('admin_menu_init', 'cbk_password_admin_menu');


/*
 * Admin header
 */

function cbk_password_admin_css() {
    $page = Params::getParam('page');
    switch ($page) {
        case('plugins'):
            $string = Params::getParam('file');
            $arr = explode("/", $string, 2);
            $first = $arr[0];
            if ($first == 'cbk_password') {
                /*
                 * load the admin title 
                 */
                osc_add_filter('custom_plugin_title', 'cbk_password_admin_title_menu');
                /*
                 * ad body class
                 */
                osc_add_filter('admin_body_class', 'cbk_password_admin_class');

                /*
                 * Load assets
                 */
                osc_enqueue_style('cbk_password_admin_font', osc_base_url() . 'oc-content/plugins/cbk_password/include/assets/css/font/css/font-awesome.min.css');
                osc_enqueue_style('cbk_password_admin_css', osc_base_url() . 'oc-content/plugins/cbk_password/include/assets/css/admin.css');
            }
            break;
    }
}

osc_add_hook('admin_header', 'cbk_password_admin_css');

function cbk_password_admin_title_menu() {

    return '<i class="fa fa-key" aria-hidden="true"></i>
' . __('Cbk Password', 'cbk_password');
}

function cbk_password_admin_class($array) {
    $array[] = 'cbk-password';
    return $array;
}

if (!class_exists('CbkAuthorClass')) {
    require_once 'CbkAuthor/CbkClass.php';
    $class = new CbkAuthorClass();
    $class->init();
}