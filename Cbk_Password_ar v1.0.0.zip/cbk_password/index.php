<?php

if ((!defined('ABS_PATH')))
    exit('ABS_PATH is not loaded. Direct access is not allowed.');
/*
 * Copyright (C) 2019 Puiu Calin
 * This program is a commercial software: is forbidden to use this software without licence, 
 * on multiple installations, and by purchasing from other source than those authorized for the sale of software.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * Single Domain License non-transferable only to use in one domain. 
 * For multiple domains usage is required to purchase the product multiple times.
 */

/*
  Plugin Name: Cbk Password
  Plugin URI: http://osclass.calinbehtuk.ro/
  Description: Force users to use a strong password.
  Version: 1.0.0
  Author: Puiu Calin
  Author URI: http://osclass.calinbehtuk.ro/
  Plugin update URI: cbk-password
  Short Name: cbk-password
 */


define('CBK_PASSWORD_VERSION', '100');
define('CBK_PASSWORD_RIGHTS', 1);
require_once 'include/load.php';

function cbk_password_install() {
    
}

function cbk_password_uninstall() {
    
}

osc_register_plugin(osc_plugin_path(__FILE__), 'cbk_password_install');
osc_add_hook(osc_plugin_path(__FILE__) . "_uninstall", 'cbk_password_uninstall');
