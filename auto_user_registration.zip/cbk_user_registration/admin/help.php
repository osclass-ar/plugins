<?php
/*
 * Copyright (C) 2018 Puiu Calin
 * This program is a commercial software: is forbidden to use this software without licence, 
 * on multiple installations, and by purchasing from other source than those authorized for the sale of software.
 * Unauthorized copying of this file, via any medium is strictly prohibited
 */
if ((!defined('ABS_PATH')))
    exit('ABS_PATH is not loaded. Direct access is not allowed.');

if (!OC_ADMIN)
    exit('User access is not allowed.');
?>
<link href="<?php echo osc_base_url() . 'oc-content/plugins/cbk_user_registration/css/admin.css'; ?>" rel="stylesheet" type="text/css" />
<div class="cbk_help_t">
    <h2><?php _e('Settings', 'cbk_user_registration'); ?></h2>
    <form action="<?php echo osc_admin_render_plugin_url('cbk_user_registration/admin/help.php'); ?>" method="post" enctype="multipart/form-data">  
        <input type="hidden" name="action_specific" value="settings_done" />
        <fieldset>
            <div class="form-horizontal">
                <div class="form-row">
                    <div class="form-label"><?php _e('Embedding', 'cbk_user_registration'); ?></div>
                    <div class="form-controls">
                        <select name="auto" id="auto">
                            <option value="1" <?php
                            if (osc_get_preference('auto', 'cbk_user_registration') !== '0') {
                                echo 'selected="selected"';
                            }
                            ?>><?php _e('Auto', 'cbk_user_registration'); ?></option> 
                            <option value="0"<?php
                            if (osc_get_preference('auto', 'cbk_user_registration') !== '1') {
                                echo 'selected="selected"';
                            }
                            ?>><?php _e('Manual', 'cbk_user_registration'); ?></option>
                        </select>
                        <div class="help-box"><?php _e('Display the checkbox that allow users to create an account when publish the item.', 'cbk_user_registration'); ?></div>		
                    </div>		
                </div>
            </div>
            <div class="form-actions">
                <input type="submit" value="<?php _e('Save changes', 'cbk_user_registration'); ?>" class="btn btn-submit" />
            </div>
        </fieldset>
    </form>
</div>
<div class="cbk_help_r">
    <h3><?php _e('Help', 'cbk_user_registration'); ?></h3>
    <strong><?php _e('The plugin will allow unregistered user to create an account when the item is publish.', 'cbk_user_registration'); ?></strong>
    <br />
    <br />
    <?php _e('The checkbox that the user will check if they want an account on the site, will be auto embedded or you can include the line manual in your theme if you don\'t like the area where the checkbox is displayed.', 'cbk_user_registration'); ?>
    <br />
    <br />
    <?php _e('Edit the file item-post.php from your theme and add the following line in the area that you want to display the checkbox, if you don\'t like the auto embed option:', 'cbk_user_registration'); ?>  
    <pre>
    &lt;?php if(function_exists('cbk_user_registration_checkbox')){cbk_user_registration_checkbox();} ?&gt;
    </pre>
    <?php _e('The user will receive an email with the login credentials if the account is created, in this email the user will have the auto generated password and the email used for login.', 'cbk_user_registration'); ?>
   <br />
   <br />
<center>
<iframe width="560" height="315" src="https://www.youtube.com/embed/U6zmfHchY2k" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</center>
</div>
<div class="cbk_author">
    <div class="autor_calinbehtuk">
        <span class="p_ro"></span><span></span> &#9400; 
        <?php echo date("Y"); ?> 
        <?php _e('All rights reserved', 'cbk_user_registration'); ?>
         <a target="_blank" href="https://osclass-ar.com/"><?php _e('Contact', 'cbk_user_registration'); ?></a>
        
    </div>

<?php
switch (Params::getParam('action_specific')) {
    case('settings_done'):
        $auto = Params::getParam('auto');
        osc_set_preference('auto', ($auto ? '1' : '0'), 'cbk_user_registration');
        osc_add_flash_ok_message(__('Plugin settings updated correctly', 'cbk_user_registration'), 'admin');
        header("Location:" . osc_admin_render_plugin_url('cbk_user_registration/admin/help.php'));
        break;
}