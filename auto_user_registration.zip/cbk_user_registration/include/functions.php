<?php
/*
 * Copyright (C) 2018 Puiu Calin
 * This program is a commercial software: is forbidden to use this software without licence, 
 * on multiple installations, and by purchasing from other source than those authorized for the sale of software.
 * Unauthorized copying of this file, via any medium is strictly prohibited
 */

function cbk_user_registration_insert($item) {
    if ($item['fk_i_user_id'] == NULL) {
        $name = $item['s_contact_name'];
        $email = $item['s_contact_email'];
        $aux_password = osc_genRandomPassword();

        $error = '';
        $flash_error = '';
        //make some checks
        if ($name == '') {
            $flash_error .= _m('The name cannot be empty') . PHP_EOL;
            $error = true;
        }
        if (!osc_validate_email($email)) {
            $flash_error .= _m('The email is not valid') . PHP_EOL;
            $error = true;
        }

        if ($error) {
            //ups some error
            osc_add_flash_error_message($flash_error);
        } else {
            //save user
            //prepare data        
            $date = date('Y-m-d H:i:s');
            $input['s_name'] = $name;
            $input['dt_reg_date'] = $date;
            $input['s_secret'] = osc_genRandomPassword();
            $input['s_access_ip'] = Params::getServerParam('REMOTE_ADDR');
            $input['s_email'] = $email;
            $input['s_password'] = osc_hash_password($aux_password);
            $input['s_username'] = '';
            $input['fk_c_country_code'] = $item['fk_c_country_code'];
            $input['s_country'] = $item['s_country'];
            $input['fk_i_region_id'] = $item['fk_i_region_id'];
            $input['s_region'] = $item['s_region'];
            $input['fk_i_city_id'] = $item['fk_i_city_id'];
            $input['s_city'] = $item['s_city'];
            $input['s_city_area'] = $item['s_city_area'];
            $input['s_address'] = $item['s_address'];
            $input['s_zip'] = $item['s_zip'];

            //run normal hook for pre register
            osc_run_hook('pre_user_post');


            require_once LIB_PATH . 'osclass/UserActions.php';
            $userActions = User::newInstance();

            $userActions->insert($input);
            $userId = $userActions->dao->insertedId();

            if ($input['s_username'] == '') {
                $userActions->update(
                        array('s_username' => $userId)
                        , array('pk_i_id' => $userId)
                );
            }
            Log::newInstance()->insertLog('user', 'registerCbkPlugin', $userId, $email, 'user', $userId);
            $user = $userActions->findByPrimaryKey($userId);
            if (osc_notify_new_user()) {
                osc_run_hook('hook_email_admin_new_user', $user);
            }

            if (osc_user_validation_enabled()) {
                osc_run_hook('hook_email_user_validation', $user, $input);
                // update items with s_contact_email the same as new user email
                $items_updated = Item::newInstance()->update(array('fk_i_user_id' => $userId, 's_contact_name' => $input['s_name']), array('s_contact_email' => $input['s_email']));
                if ($items_updated !== false && $items_updated > 0) {
                    $items_updated = (int) $items_updated;
                    $sql = sprintf('UPDATE %st_user SET i_items = i_items + ' . $items_updated . ' WHERE pk_i_id = %d', DB_TABLE_PREFIX, $userId);
                    User::newInstance()->dao->query($sql);
                }

                // update alerts user id with the same email
                Alerts::newInstance()->update(array('fk_i_user_id' => $userId), array('s_email' => $input['s_email']));

                osc_add_flash_ok_message(_m('The user has been created. An activation email has been sent'));
            } else {
                $userActions->update(
                        array('b_active' => '1')
                        , array('pk_i_id' => $userId)
                );

                // update items with s_contact_email the same as new user email
                $items_updated = Item::newInstance()->update(array('fk_i_user_id' => $userId, 's_contact_name' => $input['s_name']), array('s_contact_email' => $input['s_email']));
                if ($items_updated !== false && $items_updated > 0) {
                    $items_updated = (int) $items_updated;
                    $sql = sprintf('UPDATE %st_user SET i_items = i_items + ' . $items_updated . ' WHERE pk_i_id = %d', DB_TABLE_PREFIX, $userId);
                    User::newInstance()->dao->query($sql);
                }

                // update alerts user id with the same email
                Alerts::newInstance()->update(array('fk_i_user_id' => $userId), array('s_email' => $input['s_email']));
                osc_add_flash_ok_message(_m('Your account has been created successfully'));
            }
            //run osclass hook
            osc_run_hook('user_register_completed', $userId);

            //send email
            cbk_user_registration_email($name, $email, $aux_password);
        }
    }
}

function cbk_user_registration_checkbox() {
    if (!osc_is_web_user_logged_in()) {
        ?>
        <div class="row control-group">
            <div class="controls checkbox">
                <input style="width:14px !important;" id="cbk_registration" name="cbk_registration" value="1" type="checkbox"> <label for="cbk_registration"><?php _e('Create an account', 'cbk_user_registration'); ?></label>
            </div>
        </div>
        <?php
    }
}

if (!OC_ADMIN && osc_get_preference('auto', 'cbk_user_registration') == 1) {
    osc_add_hook('item_form', 'cbk_user_registration_checkbox');
}

function cbk_user_registration_email($name, $email, $aux_password) {
    $mPages = new Page();
    $aPage = $mPages->findByInternalName('email_cbk_registration');
    $locale = osc_current_user_locale();
    $content = array();
    if (isset($aPage['locale'][$locale]['s_title'])) {
        $content = $aPage['locale'][$locale];
    } else {
        $content = current($aPage['locale']);
    }

    $web_link = '<a href="' . osc_base_url() . '">' . osc_page_title() . '</a>';
    $words = array();
    $words[] = array('{USERNAME}', '{USER_EMAIL}', '{PASSWORD}', '{WEB_LINK}');
    $words[] = array($name, $email, $aux_password, $web_link);

    $title = osc_mailBeauty($content['s_title'], $words);
    $body = osc_mailBeauty($content['s_text'], $words);

    $emailParams = array('subject' => $title
        , 'to' => $email
        , 'to_name' => $name
        , 'body' => $body
        , 'alt_body' => $body);

    osc_sendMail($emailParams);
}

function cbk_user_registration_update() {
    osc_set_preference('version', CBK_USER_REGISTRATION_VERSION, 'cbk_user_registration');
}

if (osc_plugin_is_enabled('cbk_user_registration/index.php')) {
    if (osc_get_preference('version', 'cbk_user_registration') < CBK_USER_REGISTRATION_VERSION) {
        cbk_user_registration_update();
    }
}