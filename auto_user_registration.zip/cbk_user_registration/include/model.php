<?php

/*
 * Copyright (C) 2018 Puiu Calin
 * This program is a commercial software: is forbidden to use this software without licence, 
 * on multiple installations, and by purchasing from other source than those authorized for the sale of software.
 * Unauthorized copying of this file, via any medium is strictly prohibited
 */

class CbkUserRegistration extends DAO {

    private static $instance;

    public static function newInstance() {
        if (!self::$instance instanceof self) {
            self::$instance = new self;
        }
        return self::$instance;
    }

    function __construct() {
        parent::__construct();
    }

    public function install() {
        $this->emails();
        osc_set_preference('auto', '1', 'cbk_user_registration');
        osc_set_preference('version', CBK_USER_REGISTRATION_VERSION, 'cbk_user_registration');
    }

    public function uninstall() {
        Page::newInstance()->deleteByInternalName('email_cbk_registration');
    }

    public function emails() {
        $description[osc_language()]['s_title'] = 'Hi {USERNAME}, your account credentials.';
        $description[osc_language()]['s_text'] = '<p>Hi {USERNAME}!</p><p>You request a registration on your site. Your account was created and you will find your login details below.</p><p>Email: <strong>{USER_EMAIL}</p><p>Password: <strong>{PASSWORD}</strong></p><p>Regards,</p><p>{WEB_LINK}</p>';
        Page::newInstance()->insert(array('s_internal_name' => 'email_cbk_registration', 'b_indelible' => '1'), $description);
    }

    public function getTableUser() {
        return DB_TABLE_PREFIX . 't_user';
    }

    public function getTableItem() {
        return DB_TABLE_PREFIX . 't_item';
    }



}