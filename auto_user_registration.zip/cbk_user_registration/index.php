<?php

/*
 * Copyright (C) 2018 Puiu Calin
 * This program is a commercial software: is forbidden to use this software without licence, 
 * on multiple installations, and by purchasing from other source than those authorized for the sale of software.
 * Unauthorized copying of this file, via any medium is strictly prohibited
 */

/*
  Plugin Name: User Registration
  Plugin URI: 
  Description: Auto register the user on publish item.
  Version: 1.0.0
  Author: Puiu Calin
  Author URI: 
  Plugin update URI: cbk-user-registration
 */

define('CBK_USER_REGISTRATION_VERSION', '100');

require_once 'include/model.php';
require_once 'include/functions.php';


function cbk_user_registration_install() {
    CbkUserRegistration::newInstance()->install();
}

function cbk_user_registration_uninstall() {
    CbkUserRegistration::newInstance()->uninstall();
}

function cbk_user_registration_admin_menu() {
    osc_admin_menu_plugins(__('CbK User Registration', 'cbk_user_registration'), osc_admin_render_plugin_url(osc_plugin_path(dirname(__FILE__)) . '/admin/help.php'), 'cbk_user_registration');
}

function cbk_user_registration($item) {
    if (!osc_is_web_user_logged_in() && Params::getParam('cbk_registration') == 1) {
        cbk_user_registration_insert($item);
    }
}

osc_add_hook('posted_item', 'cbk_user_registration');
osc_add_hook('admin_menu_init', 'cbk_user_registration_admin_menu');
osc_register_plugin(osc_plugin_path(__FILE__), 'cbk_user_registration_install');
osc_add_hook(osc_plugin_path(__FILE__) . "_uninstall", 'cbk_user_registration_uninstall');