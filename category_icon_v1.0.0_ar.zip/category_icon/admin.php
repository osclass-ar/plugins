<h2 class="render-title"><?php _e('Category icon', 'category_icon'); ?></h2>
<div class="category_icon_add_box">
    <div class="left">
        <form action="<?php echo osc_admin_render_plugin_url('category_icon/admin.php'); ?>" method="post"
              enctype="multipart/form-data">
            <input type="hidden" name="newadd" value="true"/>
            <fieldset>
                <div class="form-horizontal">
                    <div class="form-row">
                        <div class="form-label"><?php _e('Category', 'category_icon') ?></div>
                        <div class="form-controls">
                            <div class="photo_container">
                                <?php osc_categories_select('sCategory', null, __('Select a category', 'category_icon')); ?><br>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-label"><?php _e('Image', 'category_icon') ?></div>
                        <div class="form-controls">
                            <div class="photo_container">
                                <input type="file" name="imageName"/>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-label"></div>
                        <div class="form-controls">
                            <input type="submit" value="<?php _e('Save changes', 'category_icon') ?>" class="btn btn-submit">
                        </div>
                    </div>
                </div>
            </fieldset>
        </form>
    </div>
    <div class="right">
        <h2><?php _e('Info category icon', 'category_icon') ?></h2>

        <p><?php _e('Category icon plugin allows you to associates an icon categories.', 'category_icon') ?></p>
        <h4><?php _e('How does plugin work?', 'category_icon') ?></h4>
        <p><?php _e('Add this code into your categories loop', 'category_icon') ?></p>
        <pre>
&lt;?php while (osc_has_categories()) { ?&gt;
&lt;?php if(get_category_icon(osc_category_id())) { ?&gt;
&lt;img src=&quot;&lt;?php echo get_category_icon(osc_category_id()); ?&gt;&quot; /&gt;
&lt;?php } echo osc_category_name(); ?&gt;
&lt;?php } ?&gt;
        </pre>
        <p><?php _e('It compatible with Osclass version 3.3.1 or higher', 'category_icon') ?></p>
        <?php printf(__('You have %s version', 'category_icon'), OSCLASS_VERSION); ?>
    </div>
</div>

<div class="category_icon_box">
    <table class="table">
        <tr>
            <th><?php _e('ID', 'category_icon') ?></th>
            <th><?php _e('Icon', 'category_icon') ?></th>
            <th><?php _e('Category', 'category_icon') ?></th>
            <th><?php _e('Action', 'category_icon') ?></th>
        </tr>
        <?php
        if (count(get_all_categories_icon()) > 0) {
            foreach (get_all_categories_icon() as $catI) {
                $category_icon = osc_get_category('id', $catI['pk_i_id']);
                ?>
                <tr>
                    <td>
                        <?php echo $catI['bs_key_id']; ?>
                    </td>
                    <td><img src="<?php echo UPLOAD_PATH . $catI['bs_image_name']; ?>"/></td>
                    <td><?php echo $category_icon['s_name']; ?></td>
                    <td><a class="delete"
                           onclick="javascript:return confirm('<?php _e('This action can not be undone. Are you sure you want to continue?', 'category_icon'); ?>')"
                           href="<?php echo osc_admin_render_plugin_url('category_icon/admin.php') . '&delete=' . $catI['bs_key_id']; ?>"><?php _e('Delete', 'category_icon'); ?></a>
                    </td>
                </tr>
            <?php }
        } else {
            ?>
            <tr>
                <td colspan="4">
                    <i><?php _e('No images added', 'category_icon'); ?></i>
                </td>
            </tr>
            <?php
        }
        ?>
    </table>
</div>