<?php
  // Create menu
  $title = __('Configure', 'loan');
  lon_menu($title);


  // GET & UPDATE PARAMETERS
  // $variable = mb_param_update( 'param_name', 'form_name', 'input_type', 'plugin_var_name' );
  // input_type: check or value

  $type = mb_param_update('type', 'plugin_action', 'value', 'plugin-loan');
  $maturity_min = mb_param_update('maturity_min', 'plugin_action', 'value', 'plugin-loan');
  $maturity_max = mb_param_update('maturity_max', 'plugin_action', 'value', 'plugin-loan');
  $interest = mb_param_update('interest', 'plugin_action', 'value', 'plugin-loan');
  $color = mb_param_update('color', 'plugin_action', 'value', 'plugin-loan');
  $amount_min = mb_param_update('amount_min', 'plugin_action', 'value', 'plugin-loan');
  $amount_max = mb_param_update('amount_max', 'plugin_action', 'value', 'plugin-loan');
  $show_out_range = mb_param_update('show_out_range', 'plugin_action', 'check', 'plugin-loan');
  $hook = mb_param_update('hook', 'plugin_action', 'check', 'plugin-loan');
  $logo = mb_param_update('logo', 'plugin_action', 'value', 'plugin-loan');
  $link = mb_param_update('link', 'plugin_action', 'value', 'plugin-loan');
  $category = mb_param_update('category', 'plugin_action', 'value', 'plugin-loan');

  $category_array = explode(',', $category);


  if(Params::getParam('plugin_action') == 'done') {
    message_ok( __('Settings were successfully saved', 'loan') );
  }
?>


<div class="mb-body">

  <!-- CONFIGURE SECTION -->
  <div class="mb-box">
    <div class="mb-head"><i class="fa fa-wrench"></i> <?php _e('Configure', 'loan'); ?></div>

    <div class="mb-inside mb-minify">
      <form name="promo_form" action="<?php echo osc_admin_base_url(true); ?>" method="POST" enctype="multipart/form-data" >
        <input type="hidden" name="page" value="plugins" />
        <input type="hidden" name="action" value="renderplugin" />
        <input type="hidden" name="file" value="<?php echo osc_plugin_folder(__FILE__); ?>configure.php" />
        <input type="hidden" name="plugin_action" value="done" />

        <div class="mb-row">
          <label for="maturity_min" class="h1"><span><?php _e('Minimum Loan Maturity', 'loan'); ?></span></label> 
          <input name="maturity_min" id="maturity_min" type="text" class="" value="<?php echo $maturity_min; ?>" />
          
          <div class="mb-explain"><?php _e('Set minimum loan maturity (years or months - based on type of maturity)', 'loan'); ?></div>
        </div>

        <div class="mb-row">
          <label for="maturity_max" class="h2"><span><?php _e('Maximum Loan Maturity', 'loan'); ?></span></label> 
          <input name="maturity_max" id="maturity_max" type="text" class="" value="<?php echo $maturity_max; ?>" />
          
          <div class="mb-explain"><?php _e('Set maximum loan maturity (years or months - based on type of maturity)', 'loan'); ?></div>
        </div>

        <div class="mb-row">
          <label for="interest" class="h3"><span><?php _e('Interest', 'loan'); ?></span></label> 
          <input name="interest" id="interest" type="text" class="" value="<?php echo $interest; ?>" />
          
          <div class="mb-explain"><?php _e('Set annual loan interest in percentage (without sign as decimal number). Example: 1.25', 'loan'); ?></div>
        </div>

        <div class="mb-row">
          <label for="amount_min" class="h4"><span><?php _e('Minimum loan amount', 'loan'); ?></span></label> 
          <input name="amount_min" id="amount_min" type="text" class="" value="<?php echo $amount_min; ?>" />
          
          <div class="mb-explain"><?php _e('Set minimum amount that is available for loan', 'loan'); ?></div>
        </div>

        <div class="mb-row">
          <label for="amount_max" class="h5"><span><?php _e('Maximum loan amount', 'loan'); ?></span></label> 
          <input name="amount_max" id="amount_max" type="text" class="" value="<?php echo $amount_max; ?>" />
          
          <div class="mb-explain"><?php _e('Set maximum amount that is available for loan', 'loan'); ?></div>
        </div>

        <div class="mb-row">
          <label for="type" class="h6"><span><?php _e('Maturity type', 'loan'); ?></span></label> 
      
          <select name="type">
            <option value="YEAR" <?php echo ($type == 'YEAR' ? 'selected="selected"' : ''); ?>><?php _e('Years', 'loan'); ?></option>
            <option value="MONTH" <?php echo ($type == 'MONTH' ? 'selected="selected"' : ''); ?>><?php _e('Months', 'loan'); ?></option>
          </select>

          <div class="mb-explain"><?php _e('Select if maturity is in months or years. Based on this, loan calculation is adjusted.', 'loan'); ?></div>
        </div>

        <div class="mb-row">
          <label for="color" class="h11"><span><?php _e('Color scheme', 'loan'); ?></span></label> 
      
          <select name="color">
            <option value="BLUE" <?php echo ($color == 'BLUE' ? 'selected="selected"' : ''); ?>><?php _e('Blue (Default)', 'loan'); ?></option>
            <option value="RED" <?php echo ($color == 'RED' ? 'selected="selected"' : ''); ?>><?php _e('Red', 'loan'); ?></option>
            <option value="GREEN" <?php echo ($color == 'GREEN' ? 'selected="selected"' : ''); ?>><?php _e('Green', 'loan'); ?></option>
          </select>

          <div class="mb-explain"><?php _e('Select color scheme for calculator.', 'loan'); ?></div>
        </div>

        <div class="mb-row">
          <label for="logo" class="h7"><span><?php _e('Bank logo', 'loan'); ?></span></label> 
          <input name="logo" id="logo" type="text" size="60" class="" value="<?php echo $logo; ?>" />
          
          <div class="mb-explain"><?php _e('Link/URL to affliate bank or financial institution logo image. Recommended is .png/.gif image with transparent background.', 'loan'); ?></div>
        </div>

        <div class="mb-row">
          <label for="link" class="h8"><span><?php _e('Bank affliate link', 'loan'); ?></span></label> 
          <input name="link" id="link" type="text" size="60" class="" value="<?php echo $link; ?>" />
          
          <div class="mb-explain"><?php _e('Affliate link to bank or financial institution (linked to logo)', 'loan'); ?></div>
        </div>

        <div class="mb-row">
          <label for="show_out_range" class="h9"><span><?php _e('Show if out of range', 'loan'); ?></span></label> 
          <input name="show_out_range" id="show_out_range" type="checkbox" class="element-slide" <?php echo ($show_out_range == 1 ? 'checked' : ''); ?> />
          
          <div class="mb-explain"><?php _e('When enabled, loan box/calculator is shown also in case when item price is out of min-max amount of loan.', 'loan'); ?></div>
        </div>

        <div class="mb-row">
          <label for="hook" class="h12"><span><?php _e('Hook on item page', 'loan'); ?></span></label> 
          <input name="hook" id="hook" type="checkbox" class="element-slide" <?php echo ($hook == 1 ? 'checked' : ''); ?> />
          
          <div class="mb-explain"><?php _e('When enabled, loan text is automatically hooked to listing page using item_detail hook.', 'loan'); ?></div>
        </div>

        <div class="mb-row mb-row-select-multiple">
          <label for="category_multiple" class="h10"><span><?php _e('Category', 'loan'); ?></span></label> 

          <input type="hidden" name="category" id="category" value="<?php echo $category; ?>"/>
          <select id="category_multiple" name="category_multiple" multiple>
            <?php echo lon_cat_list($category_array); ?>
          </select>

          <div class="mb-explain"><?php _e('If not category selected, calculator is shown in all categories.', 'loan'); ?></div>
        </div>


        <div class="mb-row">&nbsp;</div>

        <div class="mb-foot">
          <?php if(lon_is_demo()) { ?>
            <a class="mb-button mb-has-tooltip disabled" onclick="return false;" style="cursor:not-allowed;opacity:0.5;" title="<?php echo osc_esc_html(__('This is demo site', 'loan')); ?>"><?php _e('Save', 'loan');?></a>
          <?php } else { ?>
            <button type="submit" class="mb-button"><?php _e('Save', 'loan');?></button>
          <?php } ?>
        </div>
      </form>
    </div>
  </div>


  <!-- PLUGIN INTEGRATION -->
  <div class="mb-box">
    <div class="mb-head"><i class="fa fa-wrench"></i> <?php _e('Plugin Setup', 'loan'); ?></div>

    <div class="mb-inside">

      <div class="mb-row">
        <div class="mb-line"><?php _e('In case you want to place loan text on other place than by default (using hook), disable hook, open item.php and place there following code:', 'loan'); ?>:</div>
        <div class="mb-line"><br/></div>

        <span class="mb-code">&lt;?php if(function_exists('lon_box')) { lon_box(); } ?&gt;</span>

        <div class="mb-line"><?php echo __('Note that you can place code just once to item.php, placing it multiple times may lead to errors', 'loan'); ?></div>

      </div>
    </div>
  </div>
</div>


<?php echo lon_footer(); ?>