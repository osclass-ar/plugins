<?php
  $item = Item::newInstance()->findByPrimaryKey(osc_item_id());

  $price = $item['i_price']/1000000;
  $currency_code = $item['fk_c_currency_code'];

  $currency = Currency::newInstance()->findByPrimaryKey($currency_code);
  $currency_sign = $currency['s_description'];

  $interest = lon_param('interest');

  $dif = lon_param('amount_max') - lon_param('amount_min');

  if($dif <= 1000000) { $step = 10000; }
  if($dif <= 500000) { $step = 5000; }
  if($dif <= 100000) { $step = 1000; }
  if($dif <= 50000) { $step = 500; }
  if($dif <= 1000) { $step = 100; }

  $maturity_def = round((lon_param('maturity_max') - lon_param('maturity_min'))*0.8);

  if(lon_param('type') == 'YEAR') {
    $periodicity = 12;
  } else {
    $periodicity = 1;
  }

  $mat_calc = $maturity_def*$periodicity;
  $int_calc = $interest/100/12;

  $factor = (pow(1+$int_calc, $mat_calc) - 1) / ($int_calc * pow(1+$int_calc, $mat_calc));
  $monthly_paid = round($price / $factor, 2);
  $interest_paid = round($mat_calc * $monthly_paid - $price, 2);

?>

<?php if($price >= 0 && (lon_param('show_out_range') == 1 || (lon_param('show_out_range') == 0 && ($price >= lon_param('amount_min') && $price <= lon_param('amount_max'))))) { ?>
  <div class="show-loan-wrap" id="lon-fancy-dialog">
    <div class="lon-box">
      <div class="lon-header">
        <?php _e('Loan calculator', 'loan'); ?>
        <div class="lon-close"><img src="<?php echo osc_base_url(); ?>oc-content/plugins/loan/img/close.png"/></div>
      </div>

      <div class="lon-body">
        <div class="lon-amount">
          <div class="lon-title"><?php _e('Loan amount', 'loan'); ?></div>

          <div class="lon-slider lon-slider-amount">
            <div class="lon-min"><?php echo lon_param('amount_min'); ?><?php echo $currency_sign; ?></div>
   
            <div class="lon-slide">
              <input id="sld-amount" data-slider-id='exSliderAmount' type="text" data-slider-min="<?php echo lon_param('amount_min'); ?>" data-slider-max="<?php echo lon_param('amount_max'); ?>" data-slider-step="<?php echo $step; ?>" data-slider-value="<?php echo $price; ?>"/>
              <div class="lon-line lon-l1"></div><div class="lon-line lon-l2"></div><div class="lon-line lon-l3"></div><div class="lon-line lon-l4"></div>
            </div>

            <div class="lon-max"><?php echo lon_param('amount_max'); ?><?php echo $currency_sign; ?></div>

          </div>
        </div>

        <div class="lon-maturity">
          <div class="lon-title"><?php _e('Loan maturity', 'loan'); ?></div>

          <div class="lon-slider lon-slider-maturity">
            <div class="lon-min"><?php echo lon_param('maturity_min'); ?> <?php lon_param('type') == 'YEAR' ? _e('years', 'loan') : _e('months', 'loan'); ?></div>

            <div class="lon-slide">
              <input id="sld-maturity" data-slider-id='exSliderMaturity' type="text" data-slider-min="<?php echo lon_param('maturity_min'); ?>" data-slider-max="<?php echo lon_param('maturity_max'); ?>" data-slider-step="1" data-slider-value="<?php echo $maturity_def; ?>"/>
              <div class="lon-line lon-l1"></div><div class="lon-line lon-l2"></div><div class="lon-line lon-l3"></div><div class="lon-line lon-l4"></div>
            </div>

            <div class="lon-max"><?php echo lon_param('maturity_max'); ?> <?php lon_param('type') == 'YEAR' ? _e('years', 'loan') : _e('months', 'loan'); ?></div>
          </div>
        </div>

        <div class="lon-summary">
          <div class="lon-col lon-col-1">
            <div class="lon-sub-title"><?php _e('Interest:', 'loan'); ?></div>
            <div class="lon-value">
              <input class="lon-interest" value="<?php echo lon_param('interest'); ?>" type="text" /><span>%</span>
            </div>
          </div>

          <div class="lon-col lon-col-2">
            <div class="lon-sub-title"><?php _e('Paid on interest:', 'loan'); ?></div>
            <div class="lon-value">
              <strong id="lon-total-interest"><span><?php echo $interest_paid; ?></span>&nbsp;<?php echo $currency_sign; ?></strong>
            </div>
          </div>

          <div class="lon-col lon-col-3">
            <div class="lon-sub-title"><?php _e('Monthly payment:', 'loan'); ?></div>
            <div class="lon-value">
              <strong id="lon-monthly"><span><?php echo $monthly_paid; ?></span>&nbsp;<?php echo $currency_sign; ?></strong>
            </div>
          </div>
        </div>

      </div>

      <div class="lon-footer">
        <div class="lon-left">
          <div class="lon-row">
            <i class="fa fa-check-circle"></i> <?php _e('No hidden fees', 'loan'); ?>
          </div>

          <div class="lon-row">
            <i class="fa fa-check-circle"></i> <?php _e('Prices are only informal', 'loan'); ?>
          </div>
        </div>

        <?php if(lon_param('logo') <> '') { ?>
          <div class="lon-right">
            <?php if(lon_param('link') <> '') { ?>
              <a href="<?php echo lon_param('link'); ?>">
            <?php } ?>

            <img src="<?php echo lon_param('logo'); ?>" alt="<?php echo osc_esc_html('Loan/mortage', 'loan'); ?>"/>

            <?php if(lon_param('link') <> '') { ?>
              </a>
            <?php } ?>
          </div>
        <?php } ?>
      </div>
    </div>
  </div>
<?php } ?>