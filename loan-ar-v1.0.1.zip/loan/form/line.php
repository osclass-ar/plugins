<?php
  $item = Item::newInstance()->findByPrimaryKey(osc_item_id());

  $price = $item['i_price']/1000000;
  $currency_code = $item['fk_c_currency_code'];

  $currency = Currency::newInstance()->findByPrimaryKey($currency_code);
  $currency_sign = $currency['s_description'];

  $interest = lon_param('interest');
  $maturity_def = round((lon_param('maturity_max') - lon_param('maturity_min'))*0.8);

  if(lon_param('type') == 'YEAR') {
    $periodicity = 12;
  } else {
    $periodicity = 1;
  }

  $mat_calc = lon_param('maturity_max')*$periodicity;
  $int_calc = $interest/100/12;

  $factor = (pow(1+$int_calc, $mat_calc) - 1) / ($int_calc * pow(1+$int_calc, $mat_calc));
  $monthly_paid = round($price / $factor, 2);
  $interest_paid = round($mat_calc * $monthly_paid - $price, 2);

?>

<?php if($price >= 0 && (lon_param('show_out_range') == 1 || (lon_param('show_out_range') == 0 && ($price >= lon_param('amount_min') && $price <= lon_param('amount_max'))))) { ?>
  <a href="#" id="show-loan" class="show-loan-link" data-item-id="<?php echo osc_item_id(); ?>">
    <i class="fa fa-dollar"></i>
    <?php echo sprintf(__('Finance this item from %s per month', 'loan'), $monthly_paid .'&nbsp;' .$currency_sign); ?>
  </a>
<?php } ?>