<?php
/*
  Plugin Name: Loan Calculator Plugin
  Plugin URI: https://osclasspoint.com
  Description: Provide users to calculate loan on your items
  Version: 1.0.1
  Author: MB Themes
  Author URI: https://www.mb-themes.com
  Author Email: info@mb-themes.com
  Short Name: loan
  Plugin update URI: loan
  Support URI: https://forums.osclasspoint.com/loan-calculator-plugin/
  Product Key: J9wVtDVg2WDgm3cS6fXi
*/

require_once osc_plugins_path() . osc_plugin_folder(__FILE__) . 'functions.php';



osc_enqueue_style('lon-slider', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/10.0.2/css/bootstrap-slider.min.css');
osc_enqueue_style('lon-user-style', osc_base_url() . 'oc-content/plugins/loan/css/user.css?v=' . date('YmdHis'));
osc_enqueue_style('font-awesome47', '//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
osc_register_script('lon-slider', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/10.0.2/bootstrap-slider.min.js', 'jquery');
osc_register_script('lon-user', osc_base_url() . 'oc-content/plugins/loan/js/user.js?v=' . date('YmdHis'), array('jquery', 'lon-slider'));



// ADD SCRIPTS TO HEADER
function lon_header_scripts() {
  if(osc_is_ad_page()) {
    osc_enqueue_script('lon-slider');
    osc_enqueue_script('lon-user');
  }
}

osc_add_hook('header','lon_header_scripts');


// ADD SCRIPTS TO FOOTER
function lon_footer_scripts() {
  if(osc_is_ad_page()) {
    require_once 'form/box.php';

    $item = Item::newInstance()->findByPrimaryKey(osc_item_id());
    $currency_code = $item['fk_c_currency_code'];
    $currency = Currency::newInstance()->findByPrimaryKey($currency_code);
    $currency_sign = $currency['s_description'];

    ?>
      <script>var lon_type = "<?php echo lon_param('type'); ?>";</script>
      <style>
        .lon-amount .lon-slide .tooltip-inner:after {content:"<?php echo $currency_sign; ?>";}
        .lon-maturity .lon-slide .tooltip-inner:after {content:" <?php lon_param('type') == 'YEAR' ? _e('years', 'loan') : _e('months', 'loan'); ?>";}

         <?php if(lon_param('color') == 'GREEN') { ?>
           .lon-box .lon-header {background:#77d4a1;}
           .lon-title, .lon-value, .lon-value input.lon-interest[type="text"]:not([type="radio"]):not([type="checkbox"]):not([type="file"]):not([type="submit"]) {color:#43ce9c;}
           .lon-min, .lon-max, .lon-sub-title, .lon-row i {color:#62debd;}
           .lon-slide .tooltip-inner, .lon-slide .slider-handle, .lon-footer .lon-right {background:#63dfb8;}
           .lon-slide .tooltip.top .tooltip-arrow {border-top-color:#63dfb8;}
           .lon-footer .lon-left {background:#43ce9c;}
         <?php } else if(lon_param('color') == 'RED') { ?>
           .lon-box .lon-header {background:#d47777;}
           .lon-title, .lon-value, .lon-value input.lon-interest[type="text"]:not([type="radio"]):not([type="checkbox"]):not([type="file"]):not([type="submit"]) {color:#ce4343;}
           .lon-min, .lon-max, .lon-sub-title, .lon-row i {color:#de6262;}
           .lon-slide .tooltip-inner, .lon-slide .slider-handle, .lon-footer .lon-right {background:#df6363;}
           .lon-slide .tooltip.top .tooltip-arrow {border-top-color:#df6363;}
           .lon-footer .lon-left {background:#ce4343;}
         <?php } ?>
      </style>
    <?php
  }
}

osc_add_hook('footer','lon_footer_scripts');





// LOAN BOX
function lon_box() {
  if(in_array(osc_item_category_id(), explode(',', lon_param('category'))) || lon_param('category') == '') { 
    require_once 'form/line.php';
  }
}


// BOX TO ITEM_DETAIL USING HOOK
function lon_box_hook() {
  if(lon_param('hook') == 1) {
    lon_box();
  }
}

osc_add_hook('item_detail','lon_box_hook');



// INSTALL FUNCTION - DEFINE VARIABLES
function lon_call_after_install() {
  osc_set_preference('type', 'YEAR', 'plugin-loan', 'STRING');
  osc_set_preference('maturity_min', 5, 'plugin-loan', 'INTEGER');
  osc_set_preference('maturity_max', 30, 'plugin-loan', 'INTEGER');
  osc_set_preference('interest', '1.5', 'plugin-loan', 'STRING');
  osc_set_preference('color', 'BLUE', 'plugin-loan', 'STRING');
  osc_set_preference('category', '', 'plugin-loan', 'STRING');
  osc_set_preference('amount_min', 10000, 'plugin-loan', 'INTEGER');
  osc_set_preference('amount_max', 1000000, 'plugin-loan', 'INTEGER');
  osc_set_preference('show_out_range', 1, 'plugin-loan', 'INTEGER');
  osc_set_preference('hook', 1, 'plugin-loan', 'INTEGER');
  osc_set_preference('logo', '', 'plugin-loan', 'STRING');
  osc_set_preference('link', '', 'plugin-loan', 'STRING');
}


function lon_call_after_uninstall() {
  osc_delete_preference('type', 'plugin-loan');
  osc_delete_preference('maturity_min', 'plugin-loan');
  osc_delete_preference('maturity_max', 'plugin-loan');
  osc_delete_preference('interest', 'plugin-loan');
  osc_delete_preference('color', 'plugin-loan');
  osc_delete_preference('category', 'plugin-loan');
  osc_delete_preference('amount_min', 'plugin-loan');
  osc_delete_preference('amount_max', 'plugin-loan');
  osc_delete_preference('show_out_range', 'plugin-loan');
  osc_delete_preference('hook', 'plugin-loan');
  osc_delete_preference('logo', 'plugin-loan');
  osc_delete_preference('link', 'plugin-loan');
}



// ADMIN MENU
function lon_menu($title = NULL) {
  echo '<link href="' . osc_base_url() . 'oc-content/plugins/loan/css/admin.css?v=' . date('YmdHis') . '" rel="stylesheet" type="text/css" />';
  echo '<link href="' . osc_base_url() . 'oc-content/plugins/loan/css/bootstrap-switch.css" rel="stylesheet" type="text/css" />';
  echo '<link href="' . osc_base_url() . 'oc-content/plugins/loan/css/tipped.css" rel="stylesheet" type="text/css" />';
  echo '<link href="//fonts.googleapis.com/css?family=Open+Sans:300,600&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css" />';
  echo '<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />';
  echo '<script src="' . osc_base_url() . 'oc-content/plugins/loan/js/admin.js?v=' . date('YmdHis') . '"></script>';
  echo '<script src="' . osc_base_url() . 'oc-content/plugins/loan/js/tipped.js"></script>';
  echo '<script src="' . osc_base_url() . 'oc-content/plugins/loan/js/bootstrap-switch.js"></script>';



  if( $title == '') { $title = __('Configure', 'loan'); }

  $text  = '<div class="mb-head">';
  $text .= '<div class="mb-head-left">';
  $text .= '<h1>' . $title . '</h1>';
  $text .= '<h2>Loan Calculator Plugin</h2>';
  $text .= '</div>';
  $text .= '<div class="mb-head-right">';
  $text .= '<ul class="mb-menu">';
  $text .= '<li><a href="' . osc_base_url() . 'oc-admin/index.php?page=plugins&action=renderplugin&file=loan/admin/configure.php"><i class="fa fa-wrench"></i><span>' . __('Configure', 'loan') . '</span></a></li>';
  $text .= '</ul>';
  $text .= '</div>';
  $text .= '</div>';

  echo $text;
}



// ADMIN FOOTER
function lon_footer() {
  $pluginInfo = osc_plugin_get_info('loan/index.php');
  $text  = '<div class="mb-footer">';
  $text .= '<a target="_blank" class="mb-developer" href="https://osclasspoint.com"><img src="https://osclasspoint.com/favicon.ico" alt="OsclassPoint Market" /> OsclassPoint Market</a>';
  $text .= '<a target="_blank" href="' . $pluginInfo['support_uri'] . '"><i class="fa fa-bug"></i> ' . __('Report Bug', 'loan') . '</a>';
  $text .= '<a target="_blank" href="https://forums.osclasspoint.com/"><i class="fa fa-handshake-o"></i> ' . __('Support Forums', 'loan') . '</a>';
  $text .= '<a target="_blank" class="mb-last" href="mailto:info@osclasspoint.com"><i class="fa fa-envelope"></i> ' . __('Contact Us', 'loan') . '</a>';
  $text .= '<span class="mb-version">v' . $pluginInfo['version'] . '</span>';
  $text .= '</div>';

  return $text;
}



// ADD MENU LINK TO PLUGIN LIST
function lon_admin_menu() {
echo '<h3><a href="#">Loan Calculator Plugin</a></h3>
<ul> 
  <li><a style="color:#2eacce;" href="' . osc_admin_render_plugin_url(osc_plugin_path(dirname(__FILE__)) . '/admin/configure.php') . '">&raquo; ' . __('Configure', 'loan') . '</a></li>
</ul>';
}


// ADD MENU TO PLUGINS MENU LIST
osc_add_hook('admin_menu','lon_admin_menu', 1);



// DISPLAY CONFIGURE LINK IN LIST OF PLUGINS
function lon_conf() {
  osc_admin_render_plugin( osc_plugin_path( dirname(__FILE__) ) . '/admin/configure.php' );
}

osc_add_hook( osc_plugin_path( __FILE__ ) . '_configure', 'lon_conf' );	


// CALL WHEN PLUGIN IS ACTIVATED - INSTALLED
osc_register_plugin(osc_plugin_path(__FILE__), 'lon_call_after_install');

// SHOW UNINSTALL LINK
osc_add_hook(osc_plugin_path(__FILE__) . '_uninstall', 'lon_call_after_uninstall');

?>