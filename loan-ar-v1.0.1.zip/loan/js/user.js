$(document).ready(function() {
  var sldAmount = new Slider("#sld-amount", {
    tooltip: 'always'
  });


  var sldMaturity = new Slider("#sld-maturity", {
    tooltip: 'always'
  });


  $('#sld-amount, #sld-maturity').on('slide change', function(slideEvt) {
    //console.log(slideEvt.value);

    $('strong#lon-monthly > span').text(lonGetMonthly());
    $('strong#lon-total-interest > span').text(lonGetInterest());
  });


  $('body').on('change keyup keypress keydown', 'input.lon-interest', function(){
    $('strong#lon-monthly > span').text(lonGetMonthly());
    $('strong#lon-total-interest > span').text(lonGetInterest());
  });


  // CLOSE BOX
  $('body').on('click', '.lon-close', function(){
    $('#lon-fancy-dialog').fadeOut(200);
  });


  // SHOW LOAN BOX
  $('body').on('click', 'a.show-loan-link', function(e) {
    e.preventDefault();
    $('#lon-fancy-dialog').fadeIn(200).css('top', ($(document).scrollTop() + Math.round($(window).height()/10)) + 'px');
  });


  // CLICK OUTSIDE BOX TO CLOSE IT
  $(document).mouseup(function (e){
    var container = $("#lon-fancy-dialog");

    if (!container.is(e.target) && container.has(e.target).length === 0) {
      $('#lon-fancy-dialog').fadeOut(200);
    }
  });

});



// LOAN MONTHLY PAYMENT CALCULATOR
function lonGetMonthly() {
  if(typeof lon_type !== 'undefined') {
    if(lon_type == 'YEAR') {
      var periodicity = 12;
    } else {
      var periodicity = 1;
    }
  } else {
    var periodicity = 12;
  } 

  var interest = parseFloat($('input.lon-interest').val())/100/12;
  var maturity = parseFloat($('input#sld-maturity').val())*periodicity;
  var amount = parseFloat($('input#sld-amount').val());


  // formula >> Loan Payment = Amount / Discount Factor
  var factor = (Math.pow(1+interest, maturity) - 1) / (interest * Math.pow(1+interest, maturity))
  return (amount / factor).toFixed(2);
}


// LOAN TOTAL INTEREST CALCULATOR
function lonGetInterest() {
  if(typeof lon_type !== 'undefined') {
    if(lon_type == 'YEAR') {
      var periodicity = 12;
    } else {
      var periodicity = 1;
    }
  } else {
    var periodicity = 12;
  } 

  var maturity = parseFloat($('input#sld-maturity').val())*periodicity;
  var amount = parseFloat($('input#sld-amount').val());

  return (maturity * lonGetMonthly() - amount).toFixed(2);
}