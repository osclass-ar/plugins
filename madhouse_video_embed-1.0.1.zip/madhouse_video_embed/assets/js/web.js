;(function($) {
    $(document).ready(function() {
		   $(".js-embed").oembed(null,{
		        fallback : false,
		        embedMethod : "replace"
		    });
    });
})(jQuery);