<?php

class Madhouse_VideoEmbed_Controllers_Admin extends AdminSecBaseModel
{
    protected $settings;

    function __construct()
    {
        parent::__construct();

        // Set the settings service.
        $this->settings = Madhouse_VideoEmbed_Services_SettingsService::newInstance();
    }

    /**
     * Load the settings view.
     */
    private function doSettings()
    {
        View::newInstance()->_exportVariableToView("settings", $this->settings);
    }

    /**
     * Save the settings and redirect to settings view.
     */
    private function doSettingsPost()
    {
        $params = Params::getParam('settings');
        if ($params == "") {
            return;
        }

        /**
         * Save the settings and redirect to settings view.
         */
        Madhouse_Utils_Controllers::doSettingsPost(
            array(
                "settings"
            ),
            Params::getParamsAsArray(),
            mdh_video_embed_admin_settings_url()
        );
    }

    /**
     * Do model, catch all cases of madhouse user resoures for admin
     */
    public function doModel()
    {
        parent::doModel();

        switch (Params::getParam("route")) {
            case mdh_current_plugin_name() . "_admin_settings_post":
                $this->doSettingsPost();
                break;
            case mdh_current_plugin_name() . "_admin_settings":
            default:
                $this->doSettings();
                break;
        }
    }
}
