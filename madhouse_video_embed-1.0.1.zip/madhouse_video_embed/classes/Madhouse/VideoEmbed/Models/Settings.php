<?php

class Madhouse_VideoEmbed_Models_Settings
{
    public function getTableName()
    {
        return DB_TABLE_PREFIX . "t_preference";
    }

    public function getSection()
    {
        return mdh_current_preferences_section();
    }

    /**
     * Internal method to set settings directly.
     *
     * Use at your own peril.
     *
     * @param string    $key
     * @param Any       $value
     * @param string    $type
     */
    public function set($key, $value, $type = "STRING")
    {
        if (is_array($value)) {
            $value = json_encode($value);
        }

        return osc_set_preference(
            $key,
            $value,
            $this->getSection(),
            $type
        );
    }

    /**
     * Get preference
     * @param  string $key Settings name
     * @return String      Settings value
     */
    public function get($key)
    {
        // Get preference @ database.
        return osc_get_preference(
            $key,
            $this->getSection()
        );
    }
}
