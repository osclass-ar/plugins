<?php


class Madhouse_VideoEmbed_Models_Video extends Madhouse_DAO_BaseDAO {

    private static $instance ;

    protected $joinDAO;

    public static function newInstance()
    {
        if ( !self::$instance instanceof self ) {
            $helper = new Madhouse_DAO_Helper();
            self::$instance = new self($helper);
        }
        return self::$instance ;
    }

    /**
     * Construct
     */
    function __construct($helper)
    {
        $helper->setTableName('t_item_video');
        $helper->setFields(
        array(
            'pk_i_id',
            'fk_i_item_id',
            's_link',
        ));
        $helper->setPrimaryKey('pk_i_id');

        $this->joinDAO = User::newInstance();

        parent::__construct($helper);
    }

    public function getJoinTableName()
    {
        return $this->joinDAO->getTableName();
    }

    public function findByPrimaryKey($id)
    {
        $filter['id'] = $id;
        return $this->findVideo($filter);
    }

    public function findVideo($filter = null)
    {
        $that   = $this;
        $result = $this->helper->findBy(
            function($helper) use ($that, $filter) {

                if (isset($filter["count"]) && isset($filter["import"])) {
                    $helper->dao->select("COUNT(u.pk_i_id) as total");
                } elseif(isset($filter["count"])) {
                    $helper->dao->select("COUNT(v.pk_i_id) as total");
                } else {
                    $helper->dao->select(
                        array_merge(
                            Madhouse_Utils_Models::getFieldsPrefixed($helper, "v", "v_")
                        )
                    );
                }

                if (isset($filter["id"])) {
                    $helper->dao->where("v.pk_i_id", $filter["id"]);
                }

                if (isset($filter["item"])) {
                    $helper->dao->where("v.fk_i_item_id", $filter["item"]);
                }

                $helper->dao->from($helper->getTableName() . " v");
            },
            function($r, $helper) use ($that, $filter) {
                if (isset($filter['count'])) {
                    return $r->rowObject()->total;
                } elseif ($r->numRows() == 1) {
                    return $that->buildObject($r->row());
                } else {
                    return $this->buildObjects($r->result());
                }
            }
        );

        return  $result;
    }

    /**
     * Create a video
     * @param  Madhouse_VideoEmbed_Video $video
     * @return int          Inserted Id
     */
    public function create($video)
    {
        $insertedId = $this->helper->insert(
            array(
                'fk_i_item_id'    => $video->getItemId(),
                's_link'          => $video->getLink(),
            )
        );

        return $this->findByPrimaryKey($insertedId);
    }

    /**
     * Update a Video.
     * @param  Madhouse_VideoEmbed_Video $video
     * @return Madhouse_VideoEmbed_Video
     */
    public function edit($video)
    {

        $this->helper->update(
            array(
                'fk_i_item_id'    => $video->getItemId(),
                's_link'          => $video->getLink(),
            ),
            array(
                $this->helper->getPrimaryKey() => $video->getId()
            )
        );
        return $this->findByPrimaryKey($video->getId());
    }

    public function remove($video)
    {
        return $this->helper->deleteByPrimaryKey($video->getId());
    }

    public function buildObject($data)
    {
        $video = new Madhouse_VideoEmbed_Video(Madhouse_Utils_Collections::editKeysFromArray($data, "/^v_/", ""));
        return $video;
    }
}
