<?php

/**
 * Madhouse Video Embed Plugin class.
 * @since  1.0.0
 */
class Madhouse_VideoEmbed_Plugin
{
    /**
     * Current version of this plugin.
     *
     * @since 1.0.0
     */
    const CURRENT_VERSION   = "1.0.1";
    const UTILS_VERSION     = "1.25.2";

    public static function install()
    {
        $model = new Madhouse_VideoEmbed_Models_Settings();
        $oldVersion = $model->get("version");
        $newVersion = "1.0.0";

        if ($oldVersion == "") {

            mdh_import_sql(mdh_current_plugin_path("assets/model/install.sql", false));

            $defaultParams = array(
                'form_post_position'  => 5,
                'form_edit_position'  => 5,
                'detail_position'     => 5
            );
            $model->set("settings", $defaultParams);
            $model->set("version", $newVersion);
            osc_reset_preferences();
        }
    }

    public static function uninstall()
    {
        mdh_import_sql(mdh_current_plugin_path("assets/model/uninstall.sql", false));
        mdh_delete_preferences(mdh_current_preferences_section());
    }

    /**
     * Upgrades the model & preferences to last version.
     * @return void
     * @since  1.0.0
     */
    public static function upgrade()
    {
        $model = new Madhouse_VideoEmbed_Models_Settings();
        $oldVersion = $model->get("version");
        if (!empty($oldVersion)) {
            // Update versions
            self::upgrade101();
        }
    }

    /**
     * Upgrade 101
     */
    public static function upgrade101()
    {
        $model = new Madhouse_VideoEmbed_Models_Settings();
        $oldVersion = $model->get("version");
        $newVersion = "1.0.1";

        if (version_compare($oldVersion, $newVersion) < 0) {
            $model->set("version", $newVersion);
            osc_reset_preferences();
        }
    }


    /**
     * Init the plugin
     * @return void
     */
    public static function init()
    {
        $model = new Madhouse_VideoEmbed_Models_Settings();
        $currentVersion = $model->get("version");
        if ($currentVersion == "") {
            self::install();
        } else {
            self::upgrade();
        }

    }
}
