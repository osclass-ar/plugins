<?php

/**
 * Settings manipulation service.
 *
 * Get and set settings for this plugin.
 */
class Madhouse_VideoEmbed_Services_SettingsService
{
    /**
     * Singleton instance.
     *
     * @var type
     */
    private static $instance;

    /**
     * Data of the current settings.
     *
     * @var Array<String,Any>
     */
    private $settings;

    /**
     * Singleton.
     *
     * @since 1.0.0
     */
    public static function newInstance()
    {
        if (!self::$instance instanceof self) {
            self::$instance = new self(
                new Madhouse_VideoEmbed_Models_Settings()
            );
        }

        // Return a singleton instance.
        return self::$instance;
    }

    /**
     * Construct.
     */
    public function __construct($model)
    {
        $this->model    = $model;
        $this->settings = json_decode($model->get("settings"), true);
    }

    public function get($key, $locale = null)
    {
        if (!is_null($locale)) {
            return (isset($this->settings[$key][$locale])) ? $this->settings[$key][$locale] : null;
        }
        return (isset($this->settings[$key])) ? $this->settings[$key] : null;
    }
}