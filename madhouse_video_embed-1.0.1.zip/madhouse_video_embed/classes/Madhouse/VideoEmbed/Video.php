<?php

use Embed\Embed;
use Embed\Exceptions\InvalidUrlException;

class Madhouse_VideoEmbed_Video extends Madhouse_Entity
{
    /**
     * Informations from database.
     * @var Array<String,Any>
     */
    protected $video;

    /**
     * Constructor.
     * @param $video
     */
    function __construct($video = null)
    {
        $this->video = $video;
    }

    private function getField($name, $locale = "")
    {
        return osc_field($this->video, $name, $locale);
    }

    private function getDate($name) {
        $value = $this->getField($name);
        if ($value == "") {
            return null;
        } else {
            return new \DateTime($value);
        }
    }

    public function getId()
    {
        return $this->getField("pk_i_id");
    }

    public function getItemId()
    {
        return $this->getField("fk_i_item_id");
    }

    public function setItemId($value)
    {
        $this->video['fk_i_item_id'] = $value;
        return $this;
    }

    public function getAllowedWebsites ()
    {
        return array(
            "dailymotion",
            "youtube",
            "youtu",
            "vimeo",
            "vine",
            "instagram",
            "kickstarter",
            "funnyordie",
            "twitch",
            "twitter",
            "facebook",
        );
    }

    public function isVine() {
        $sites = array(
            "vine"
        );

        if (preg_match('#((^http|^https):\/\/|^)[\w]*\.?(' . implode("|", $sites) . ').*$#', $this->getLink())) {
            return true;
        }
        return false;
    }

    public function is16by9() {
        $sites = array(
            "dailymotion",
            "youtube",
            "youtu",
            "vimeo",
            "kickstarter",
            "funnyordie",
            "twitch",
            "vine"
        );

        if (preg_match('#((^http|^https):\/\/|^)[\w]*\.?(' . implode("|", $sites) . ').*$#', $this->getLink())) {
            return true;
        }
        return false;
    }

    public function getLink()
    {
        return $this->getField("s_link");
    }

    public function getLinkToEmbed()
    {
        $link = $this->getLink();
        $allowedWebsites = implode("|", $this->getAllowedWebsites());
        if (preg_match('#((^http|^https):\/\/|^)[\w]*\.?(' . $allowedWebsites . ').*$#', $link)) {
            if (strpos($link, 'http://') === false && strpos($link, 'https://') === false) {
                $link = 'http://'. $link;
            }
            try {
                $info = Embed::create($link);
                return $info->code;
            } catch (Exception $e) {
                return "";
            }
        }
        return "";
    }

    public function setLink($value)
    {
        $this->video['s_link'] = $value;
        return $this;
    }

    public function toArray()
    {
        return array_merge(
            parent::toArray(),
            $this->video
        );
    }
}
