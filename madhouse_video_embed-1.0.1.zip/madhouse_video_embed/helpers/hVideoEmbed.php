<?php

/**
 * Tells if the current page belongs to this plugin.
 *
 * @return bool
 *
 * @since  1.0.0
 */
function mdh_is_video_embed_page()
{
    if (preg_match('/^madhouse_video_embed.*$/', Params::getParam("route"))) {
        return true;
    }
    return false;
}

/**
 * Get the admin settings route URL.
 *
 * @return string
 *
 * @since  1.0.0
 */
function mdh_video_embed_admin_settings_url()
{
    return osc_route_admin_url(mdh_current_plugin_name() . "_admin_settings");
}

/**
 * Get route admin url to settings post
 *
 * @return string $url
 *
 * @since 1.0.0
 */
function mdh_video_embed_admin_settings_post_url() {
    return osc_route_admin_url(mdh_current_plugin_name() . '_admin_settings_post');
}

/**
 * Update the user attributes of a given user.
 *
 * @param  array $val
 *
 * @return void
 */
function mdh_video_embed_edit_completed($item = null)
{
    // If $val is array item post or edit if not user edit completed
    if (isset($item['fk_i_category_id']) && osc_is_this_category(mdh_current_plugin_name(), $item['fk_i_category_id'])) {

    	$filter['item'] = $item['pk_i_id'];

        try {
        	$video = Madhouse_VideoEmbed_Models_Video::newInstance()->findVideo($filter);
        } catch (Madhouse_NoResultsException $e) {
        	$video = false;
        }

        $videoLink = mdh_video_embed_get_parameter();

        if ($video === false) {
        	$video = new Madhouse_VideoEmbed_Video;
        	$video->setItemId($item['pk_i_id']);
        	$video->setLink($videoLink);
            Madhouse_VideoEmbed_Models_Video::newInstance()->create($video);
        } else {
        	$video->setLink($videoLink);
            Madhouse_VideoEmbed_Models_Video::newInstance()->edit($video);
        }
    }
}

/**
 * Save parameter in session in case of errors
 */
function mdh_video_embed_pre_post()
{
    if(osc_is_this_category(mdh_current_plugin_name(), Params::getParam('catId') )) {
        Session::newInstance()->_setForm('pp_video_link', mdh_video_embed_get_parameter());
        Session::newInstance()->_keepForm('pp_video_link');
    }
}

/**
 * Get video link param
 * @return string The video link
 */
function mdh_video_embed_get_parameter()
{
    if (osc_validate_text(Params::getParam('video_link'), 1, false)) {
        return Params::getParam('video_link');
    }
    return "";
}



/**
 * Gets a specific field from current user
 * @return mixed
 */
function mdh_video()
{
    if (View::newInstance()->_exists('mdh_video')) {
        return __get('mdh_video');
    }
    return false;
}
