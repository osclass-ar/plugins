<?php
/*
Plugin Name: Madhouse Video Embed
Plugin URI: https://osclassmadhouse.com/portfolio/madhouse-video-embed/
Description: Add video attribute to item.
Version: 1.0.1
Author: Madhouse
Author URI: http://osclassmadhouse.com
Short Name: madhouse_video_embed
Plugin update URI: madhouse-video-embed
*/

/*
 * ==========================================================================
 *  LOADING
 * ==========================================================================
 */

require_once __DIR__ . "/vendor/composer_components/madhouse/autoloader/autoload.php";

/**
 * Makes this plugin the first to be loaded.
 * - Bumps this plugin at the top of the active_plugins stack.
 */
function mdh_video_embed_bump_me()
{
    if(OC_ADMIN) {
        // @legacy : ALWAYS remove this if active.
        if(osc_plugin_is_enabled("madhouse_utils/index.php")) {
            Plugins::deactivate("madhouse_utils/index.php");
        }

        // Sanitize & get the {PLUGIN_NAME}/index.php.
        $path = str_replace(osc_plugins_path(), '', osc_plugin_path(__FILE__));

        if(osc_plugin_is_installed($path)) {
            // Get the active plugins.
            $plugins_list = unserialize(osc_active_plugins());
            if(!is_array($plugins_list)) {
                return false;
            }

            // Remove $path from the active plugins list
            foreach($plugins_list as $k => $v) {
                if($v == $path) {
                    unset($plugins_list[$k]);
                }
            }

            // Re-add the $path at the beginning of the active plugins.
            array_unshift($plugins_list, $path);

            // Serialize the new active_plugins list.
            osc_set_preference('active_plugins', serialize($plugins_list));

            if(Params::getParam("page") === "plugins" && Params::getParam("action") === "enable" && Params::getParam("plugin") === $path) {
                //osc_redirect_to(osc_admin_base_url(true) . "?page=plugins");
            } else {
                osc_redirect_to(osc_admin_base_url(true) . "?" . http_build_query(Params::getParamsAsArray("get")));
            }
        }
    }
}

if(!function_exists("mdh_utils") || (function_exists("mdh_utils") && (mdh_utils() === true || version_compare(mdh_utils(), Madhouse_VideoEmbed_Plugin::UTILS_VERSION) < 0))) {
    mdh_video_embed_bump_me();
} else {

	/*
     * ==========================================================================
     *  INSTALL
     * ==========================================================================
     */

    osc_register_plugin(osc_plugin_path(__FILE__), "Madhouse_Video_Embed_Plugin::install()");

    /*
     * ==========================================================================
     *  UNINSTALL
     * ==========================================================================
     */

    osc_add_hook(osc_plugin_path(__FILE__) . '_uninstall', function () {
        Madhouse_VideoEmbed_Plugin::uninstall();
    });

    /*
     * ==========================================================================
     *  INIT: install if bump, upgrade if necessary.
     * ==========================================================================
     */

    Madhouse_VideoEmbed_Plugin::init();

    /*
     * ==========================================================================
     *  LOAD FORM
     * ==========================================================================
     */

    // When registration
    osc_add_hook(
        'item_form',
        "mdh_video_embed_attributes_form",
        Madhouse_VideoEmbed_Services_SettingsService::newInstance()->get('form_post_position')
    );

    // When edit profile
    osc_add_hook(
        'item_edit',
        'mdh_video_embed_attributes_form',
        Madhouse_VideoEmbed_Services_SettingsService::newInstance()->get('form_edit_position')
    );

    function mdh_video_embed_attributes_form ($catId = null, $item_id = null) {
        if (osc_is_this_category(mdh_current_plugin_name(), $catId)) {
            if (!is_null($item_id)) {
                try {
                    $video = "";
                    $filter['item'] = $item_id;
                    $video = Madhouse_VideoEmbed_Models_Video::newInstance()->findVideo($filter);
                    View::newInstance()->_exportVariableToView('mdh_video', $video);

                } catch (Madhouse_NoResultsException $e) {
                }
            }

            if (OC_ADMIN) {
                mdh_current_plugin_path('views/admin/edit.php');
            } else {
                Madhouse_Utils_Controllers::doViewPart('edit.php');
            }
        }
    }

    /*
     * (hook: pre_item_add)
     *
     * Persists item informations to fill the form in case of any errors
     * item post
     */
    osc_add_hook('pre_item_add', 'mdh_video_embed_pre_post');

    /*
     * (hook: pre_item_edit)
     *
     * Persists item informations to fill the form in case of any errors
     * item edit
     */
    osc_add_hook('pre_item_edit', 'mdh_video_embed_pre_post');

    /*
     * (hook: edited_item)
     *
     * Update item attributes when a user create his/her item.
     */
    osc_add_hook('posted_item', 'mdh_video_embed_edit_completed', 1);

    /*
     * (hook: edited_item)
     *
     * Update or insert when a user update his/her item.
     */
    osc_add_hook('edited_item', 'mdh_video_embed_edit_completed', 1);

    /*
     * (hook: show_item)
     *
     * Export video if it exist
     */
    osc_add_hook(
        'show_item',
        function() {
            if(osc_is_this_category(mdh_current_plugin_name(), osc_item_category_id())) {

                try {
                    $video = "";
                    $filter['item'] = osc_item_id();
                    $video = Madhouse_VideoEmbed_Models_Video::newInstance()->findVideo($filter);

                    View::newInstance()->_exportVariableToView('mdh_video', $video);

                } catch (Madhouse_NoResultsException $e) {
                    // Video don't exist, do nothin
                    return;
                }
            }
        }
    );

    /*
     * (hook: item_detail)
     *
     * Add video to item (for display).
     */
    osc_add_hook(
        "item_detail",
        function ($item = null) {
            if(mdh_video()) {
                Madhouse_Utils_Controllers::doViewPart('detail.php');
            }
        },
        Madhouse_VideoEmbed_Services_SettingsService::newInstance()->get('detail_position')
    );

    /*
     * ==========================================================================
     *  REGISTER & ENQUEUE
     * ==========================================================================
     */

    if(OC_ADMIN && preg_match('/^' . mdh_current_plugin_name() . '.*$/', Params::getParam("route"))) {
        osc_register_script("jquery", mdh_current_plugin_url("vendor/bower_components/jquery/dist/jquery.js"));
    }

    osc_register_script(mdh_current_plugin_name() . "_admin", mdh_current_plugin_url("assets/js/dist/admin.min.js"));

    /*
     * ==========================================================================
     *  ROUTES
     * ==========================================================================
     */

    osc_add_hook("renderplugin_controller", function() {
        if (mdh_is_video_embed_page()) {
            // Enqueue style for admin only.
            osc_add_hook("admin_header", function () {
                osc_enqueue_style(mdh_current_plugin_name() . "_admin", mdh_current_plugin_url("assets/css/dist/admin.min.css"));
                osc_enqueue_script(mdh_current_plugin_name() . "_admin");
            });

            $filter = function ($string) {
                return __("Madhouse Video Embed", mdh_current_plugin_name());
            };

            // Page title (in <head />)
            osc_add_filter("admin_title", $filter, 10);

            // Page is madhouse-made.
            osc_add_filter("admin_body_class", function ($classes) {
                array_push($classes, "madhouse");
                return $classes;
            });

            // Page title (in <h1 />)
            osc_add_filter("custom_plugin_title", $filter);

            // Add a .row-offset to wrapping <div /> element.
            osc_add_filter("render-wrapper", function ($string) {
                return "row-offset";
            });

            $do = new Madhouse_VideoEmbed_Controllers_Admin();
            $do->doModel();
        }
    });

    osc_add_route(
        mdh_current_plugin_name() . "_admin_settings",
        mdh_current_plugin_name() . "/admin_settings/?",
        mdh_current_plugin_name() . "/admin_settings/",
        mdh_current_plugin_name() . '/views/admin/settings.php'
    );

    osc_add_route(
        mdh_current_plugin_name() . "_admin_settings_post",
        mdh_current_plugin_name() . "/admin_settings/?",
        mdh_current_plugin_name() . "/admin_settings/",
        mdh_current_plugin_name() . '/views/admin/settings.php'
    );

    /*
     * ==========================================================================
     *  ADMIN MENU
     * ==========================================================================
     */

    osc_add_hook('admin_menu_init', function () {
        osc_add_admin_submenu_divider(
            'madhouse',
            __('Video Embed', mdh_current_plugin_name()),
            mdh_current_plugin_name(),
            'administrator'
        );

        osc_add_admin_submenu_page(
            'madhouse',
            __('Settings', mdh_current_plugin_name()),
            mdh_video_embed_admin_settings_url(),
            mdh_current_plugin_name() . '_admin_settings',
            'administrator'
        );

        osc_add_admin_submenu_page(
            'madhouse',
            __('Categories', mdh_current_plugin_name()),
            osc_plugin_configure_url(mdh_current_plugin_name()),
            mdh_current_plugin_name() . '_admin_categories',
            'administrator'
        );
    });

    // This is a hack to show a Configure link at plugins table (you could also use some other hook to show a custom option panel)
    osc_add_hook(osc_plugin_path(__FILE__) . "_configure", function () {
        osc_redirect_to(mdh_video_embed_admin_settings_url());
    });

}
