<div class="form-row">
    <?php
    $detail = "";
    if (Session::newInstance()->_getForm('pp_video_link') != '') {
        $detail = Session::newInstance()->_getForm('pp_video_link');
    } elseif (mdh_video()) {
        $detail = mdh_video()->getLink();
    }
    ?>
    <label class="form-label" for="video_link"><?php _e('Video', 'madhouse_video_embed'); ?></label>
    <div class="form-controls">
        <input class="form-control" type="text" name="video_link" value="<?php echo osc_esc_html($detail); ?>">
        <div class="help-box" style="margin: 8px 0;"><?php _e("Add a link from Youbtube, Vimeo, Dailymotion, Facebook, Twitter, Vine...", "madhouse_video_embed") ?></div>
    </div>
</div>
