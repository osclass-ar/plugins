<div class="bg-white">
    <ul class="nav nav-tabs nav-underline nav-md vpadder-lg">
        <?php
            $aMenus = AdminMenu::newInstance()->get_array_menu();
        foreach ($aMenus["madhouse"]["sub"] as $key => $value) :
            if (preg_match('/^' . mdh_current_plugin_name() . '.*$/', $key)) :
        ?>
        <li class="<?php echo (Params::getParam("route") === $key) ? "active" : ""; ?>">
                <a href="<?php echo $value[1]; ?>">
                    <?php echo $value[0]; ?>
                </a>
        </li>
        <?php
            endif;
        endforeach;
        ?>
        <li class="">
            <a href="http://wearemadhouse.wordpress.com/madhouse-video-embed-documentation" target="_blank"><?php _e("Help", mdh_current_plugin_name()); ?></a>
        </li>
        <li class="">
            <a class="" href="http://market.osclass.org/user/profile/madhouse" target="_blank"><span class="label label-primary"><?php _e("See more plugins by Madhouse", mdh_current_plugin_name()); ?></span></a>
        </li>
    </ul>
</div>
