<?php if ( ! defined('OC_ADMIN')) exit('Direct access is not allowed.');?>
<?php mdh_current_plugin_path("views/admin/parts/navigation.php"); ?>

<div class="p-lg">
    <h2 class="h4 text-info"><?php _e("Categories", mdh_current_plugin_name()) ; ?></h2>
    <p><?php _e("To display video field on item post or edit you need to configure Madhouse Video Embed plugin with categories you want to let users add a video to their item.", mdh_current_plugin_name()) ; ?></strong></p>
    <a class="btn btn-info" href="<?php echo osc_plugin_configure_url(mdh_current_plugin_name()) ?>"><?php _e("Configure categories") ?></a>
</div>
<form class="form-horizontal js-seo-settings m-b-md" method="POST" action="<?php echo mdh_video_embed_admin_settings_post_url() ?>">
	<div class="p-lg bg-light lt b-b">
        <h3 class="h4 text-info"><?php _e("Form settings", mdh_current_plugin_name()) ?></h3>
        <p class="text-muted">
            <?php _e("Those settings will control the custom attributes on the item post, edit, detail page and at which position it will be displayed (rendered).", mdh_current_plugin_name()); ?>
        </p>
        <p class="text-muted m-b-lg">
            <?php _e("By default, plugins run at a priority of 5. If set to 1, the video will be displayed first, before any other plugin within the same hook. On the other hand, if set to 10, the video will be displayed after every other plugin.", mdh_current_plugin_name()); ?>
        </p>
        <div class="form-group">
            <label class="col-sm-3 control-label"><?php _e("Item post", mdh_current_plugin_name()); ?></label>
            <div class="col-sm-9">
                <!-- default_status -->
                <select name="settings[form_post_position]" class="">
                    <option value="-1"><?php _e("Don't display", mdh_current_plugin_name()); ?></option>
                    <?php for($i = 1 ; $i <=10 ; $i++): ?>
                        <option <?php echo (__get('settings')->get('form_post_position') == $i) ? 'selected="selected"': ""; ?> value="<?php echo $i; ?>"><?php echo $i ?> </option>
                    <?php endfor; ?>
                </select>
                <p class="help-block"><?php _e("Need 'item_form' hook to be displayed", mdh_current_plugin_name()); ?></p>
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label"><?php _e("Item edit", mdh_current_plugin_name()); ?></label>
            <div class="col-sm-9">
                <!-- default_status -->
                <select name="settings[form_edit_position]">
                    <option value="-1"><?php _e("Don't display", mdh_current_plugin_name()); ?></option>
                    <?php for($i = 1 ; $i <=10 ; $i++): ?>
                        <option <?php echo (__get('settings')->get('form_edit_position') == $i) ? 'selected="selected"': ""; ?> value="<?php echo $i; ?>"><?php echo $i ?> </option>
                    <?php endfor; ?>
                </select>
                <p class="help-block"><?php _e("Need 'item_edit' hook to be displayed", mdh_current_plugin_name()); ?></p>
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label"><?php _e("Item detail", mdh_current_plugin_name()); ?></label>
            <div class="col-sm-9">
                <!-- default_status -->
                <select name="settings[detail_position]">
                    <option value="-1"><?php _e("Don't display", mdh_current_plugin_name()); ?></option>
                    <?php for($i = 1 ; $i <=10 ; $i++): ?>
                        <option <?php echo (__get('settings')->get('detail_position') == $i) ? 'selected="selected"': ""; ?> value="<?php echo $i; ?>"><?php echo $i ?> </option>
                    <?php endfor; ?>
                </select>
                <p class="help-block"><?php _e("Need 'item_detail' hook to be displayed", mdh_current_plugin_name()); ?></p>
            </div>
        </div>

    </div>
	<div class="p-lg bg-light lt b-b">
        <div class="row">
            <div class="col-sm-9 col-sm-offset-3">
                <button class="btn btn-primary" type="submit">
                    <?php _e("Submit", mdh_current_plugin_name()) ?>
                </button>
            </div>
        </div>
    </div>
</form>
