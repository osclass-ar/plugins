<?php if (mdh_video()->getLinkToEmbed() != ""): ?>
	<style type="text/css">
		.mdh-video-wrapper {
			margin-top: 20px;
		    float: none;
		    clear: both;
		    width: 100%;
		    position: relative;
		    padding-bottom: 56.25%;
		    height: 0;
		}

		.mdh-video-wrapper.vine {
			padding-bottom: 100%;
		}

		.mdh-video-wrapper iframe, .mdh-video-wrapper object, .mdh-video-wrapper embed {
		    position: absolute;
		    top: 0;
		    left: 0;
		    width: 100%;
		    height: 100%;
		}

	</style>
	<div class="<?php echo (mdh_video()->is16by9()) ? "mdh-video-wrapper": "" ; ?> <?php echo (mdh_video()->isVine()) ? "vine": "" ; ?>">
		<?php echo mdh_video()->getLinkToEmbed() ?>
	</div>
<?php endif ?>
