<div class="form-group control-group">
    <?php
    $detail = "";
    if (Session::newInstance()->_getForm('pp_video_link') != '') {
        $detail = Session::newInstance()->_getForm('pp_video_link');
    } elseif (mdh_video()) {
        $detail = mdh_video()->getLink();
    }
    ?>
    <label class="control-label col-sm-3" for="video_link"><?php _e('Video', 'madhouse_video_embed'); ?></label>
    <div class="controls col-sm-9">
        <input class="form-control" type="text" name="video_link" value="<?php echo osc_esc_html($detail); ?>">
        <span class="help-block"><?php _e("Add a link from Youbtube, Vimeo, Dailymotion, Facebook, Twitter, Vine...", "madhouse_video_embed") ?></span>
    </div>
</div>
