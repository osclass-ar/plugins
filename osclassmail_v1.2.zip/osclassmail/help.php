<div id="settings_form" style="padding: 22px 0;border: 1px solid #ccc; background: #eee; ">
    <div style="padding: 0 20px 0px;">
        <div>
            <fieldset>
                <legend><?php _e('OSClass Mail Help', 'osclassmail'); ?></legend>
                <p>
                    <?php _e('OSClass mail is designed to allow an administrator to notify all users with newsletters, website status updates, or even deals of the day.', 'osclassmail'); ?>
                </p>
                <p>
                    <?php _e('To use OSClass mail, just click the Create mail and add subject link, add some content, and click the Submit button.', 'osclassmail'); ?>
                </p>
				<br>
                 <p>
                   <?php _e('Created by Randy Hough.', 'osclassmail'); ?>
                </p>
            </fieldset>
        </div>
    </div>
</div>
