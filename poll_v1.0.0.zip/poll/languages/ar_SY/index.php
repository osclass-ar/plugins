<html>

<head>

<title></title>

<meta http-equiv="Refresh" content="0; URL=https://osclass-ar.com">
</head>

<body>
<?php /* So say we all */ ?>
</html>
<!-- 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
--> 
