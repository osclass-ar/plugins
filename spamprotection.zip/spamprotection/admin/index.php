<?php 
/* simple folder protection */ 
?>