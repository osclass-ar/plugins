<?php
if (!defined('ABS_PATH')) {
    exit('Direct access is not allowed.');
}

require('backend.php');
require('frontend.php');
require('params.php');
?>