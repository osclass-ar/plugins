<?php
  // Create menu
  $title = __('Configure', 'welcome');
  wlc_menu($title);


  // GET & UPDATE PARAMETERS
  // $variable = mb_param_update( 'param_name', 'form_name', 'input_type', 'plugin_var_name' );
  // input_type: check or value


  $enabled = wlc_param_update( 'enabled', 'plugin_action', 'check', 'plugin-welcome' );
  $dev_mode = wlc_param_update( 'dev_mode', 'plugin_action', 'check', 'plugin-welcome' );
  $version = wlc_param_update( 'version', 'plugin_action', 'value', 'plugin-welcome' );
  $user_type = wlc_param_update( 'user_type', 'plugin_action', 'value', 'plugin-welcome' );
  $support = wlc_param_update( 'support', 'plugin_action', 'check', 'plugin-welcome' );
  $html1 = wlc_param_update( 'html1', 'plugin_action', 'code', 'plugin-welcome' );
  $html2 = wlc_param_update( 'html2', 'plugin_action', 'code', 'plugin-welcome' );
  $html3 = wlc_param_update( 'html3', 'plugin_action', 'code', 'plugin-welcome' );
  $html4 = wlc_param_update( 'html4', 'plugin_action', 'code', 'plugin-welcome' );
  $html5 = wlc_param_update( 'html5', 'plugin_action', 'code', 'plugin-welcome' );


  if(Params::getParam('plugin_action') == 'done') {
    message_ok( __('Settings were successfully saved', 'welcome') );
  }

?>



<div class="mb-body">
  <!-- CONFIGURE SECTION -->
  <div class="mb-box">
    <div class="mb-head"><i class="fa fa-cog"></i> <?php _e('Configure', 'welcome'); ?></div>

    <div class="mb-inside">
      <form name="promo_form" id="promo_form" action="<?php echo osc_admin_base_url(true); ?>" method="POST" enctype="multipart/form-data" >
        <input type="hidden" name="page" value="plugins" />
        <input type="hidden" name="action" value="renderplugin" />
        <input type="hidden" name="file" value="<?php echo osc_plugin_folder(__FILE__); ?>configure.php" />
        <input type="hidden" name="plugin_action" value="done" />


        <div class="mb-row">
          <label for="enabled" class="h1"><span><?php _e('Enable Box', 'welcome'); ?></span></label> 
          <input name="enabled" id="enabled" class="element-slide" type="checkbox" <?php echo ($enabled == 1 ? 'checked' : ''); ?> />
          
          <div class="mb-explain"><?php _e('When enabled, welcome box is shown on home page first time visitor comes to your site. It is not shown multiple times.', 'welcome'); ?></div>
        </div>

        <div class="mb-row">
          <label for="dev_mode" class="h10"><span><?php _e('Dev Mode', 'welcome'); ?></span></label> 
          <input name="dev_mode" id="dev_mode" class="element-slide" type="checkbox" <?php echo ($dev_mode == 1 ? 'checked' : ''); ?> />
          
          <div class="mb-explain"><?php _e('When enabled, welcome box is shown every time on homepage, no matter if user saw it or no.', 'welcome'); ?></div>
        </div>

        <div class="mb-row">
          <label for="support" class="h2"><span><?php _e('Support Author', 'welcome'); ?></span></label> 
          <input name="support" id="support" class="element-slide" type="checkbox" <?php echo ($support == 1 ? 'checked' : ''); ?> />

          <div class="mb-explain"><?php _e('Provide credits to author of this great and free plugin. It does not cost you anything, author spent time to develop this for you.', 'welcome'); ?></div>
        </div>

        <div class="mb-row">
          <label for="version" class="h4"><span><?php _e('Box version', 'welcome'); ?></span></label> 
          <input name="version" id="version" type="text" value="<?php echo $version; ?>" />

          <div class="mb-explain"><?php _e('Number. Once version is changed, welcome box is shown again to all users no matter if they saw it or no.', 'welcome'); ?></div>
        </div>

        <div class="mb-row">
          <label for="user_type" class="h3"><span><?php _e('Show box to User', 'welcome'); ?></span></label> 
          <select name="user_type">
            <option value="0" <?php echo ($user_type == 0 ? 'selected="selected"' : ''); ?>><?php _e('All users', 'welcome'); ?></option>
            <option value="1" <?php echo ($user_type == 1 ? 'selected="selected"' : ''); ?>><?php _e('Only non-logged users', 'welcome'); ?></option>
            <option value="2" <?php echo ($user_type == 2 ? 'selected="selected"' : ''); ?>><?php _e('Only logged-in users', 'welcome'); ?></option>
            <option value="3" <?php echo ($user_type == 3 ? 'selected="selected"' : ''); ?>><?php _e('Only to admin', 'welcome'); ?></option>
          </select>

          <div class="mb-explain"><?php _e('Select, if welcome box is shown to all users, non-logged users or just logged-in users.', 'welcome'); ?></div>
        </div>

        <div class="mb-row">
          <label for="html1" class="h5"><span><?php _e('Box row #1 - Image', 'welcome'); ?><br/>HTML كود</span></label> 
          <textarea name="html1" id="html1"><?php echo $html1; ?></textarea>
        </div>

        <div class="mb-row">
          <label for="html2" class="h6"><span><?php _e('Box row #2 - Title', 'welcome'); ?><br/>HTML كود</span></label> 
          <textarea name="html2" id="html2"><?php echo $html2; ?></textarea>
        </div>

        <div class="mb-row">
          <label for="html3" class="h7"><span><?php _e('Box row #3 - Subtitle', 'welcome'); ?><br/>HTML كود</span></label> 
          <textarea name="html3" id="html3"><?php echo $html3; ?></textarea>
        </div>

        <div class="mb-row">
          <label for="html4" class="h8"><span><?php _e('Box row #4 - Text', 'welcome'); ?><br/>HTML كود</span></label> 
          <textarea name="html4" id="html4"><?php echo $html4; ?></textarea>
        </div>

        <div class="mb-row">
          <label for="html5" class="h9"><span><?php _e('Box row #5 - Footer', 'welcome'); ?><br/>HTML كود</span></label> 
          <textarea name="html5" id="html5"><?php echo $html5; ?></textarea>
        </div>

        <div class="mb-row">&nbsp;</div>

        <div class="mb-foot">
          <button type="submit" class="mb-button"><?php _e('Save', 'welcome');?></button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php echo wlc_footer(); ?>