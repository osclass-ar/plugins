<?php

// SUPPORT
function wlc_support() {
  if(osc_get_preference('support', 'plugin-welcome') == 1 && osc_is_search_page()) {
    echo '<div class="wlc-support"><a href="https://osclasspoint.com/osclass-plugins">Osclass Plugins</a></div>';
  }
}

osc_add_hook('search_form', 'wlc_support', 9);


// CORE FUNCTIONS
if(!function_exists('wlc_param_update')) {
  function wlc_param_update( $param_name, $update_param_name, $type = NULL, $plugin_var_name ) {
  
    $val = '';
    if( $type == 'check') {

      // Checkbox input
      if( Params::getParam( $param_name ) == 'on' ) {
        $val = 1;
      } else {
        if( Params::getParam( $update_param_name ) == 'done' ) {
          $val = 0;
        } else {
          $val = ( osc_get_preference( $param_name, $plugin_var_name ) != '' ) ? osc_get_preference( $param_name, $plugin_var_name ) : '';
        }
      }

    } else if ($type == 'code') {

      if( Params::getParam( $update_param_name ) == 'done' && Params::existParam($param_name)) {
        $val = stripslashes(Params::getParam( $param_name, false, false ));
      } else {
        $val = ( osc_get_preference( $param_name, $plugin_var_name) != '' ) ? stripslashes(osc_get_preference( $param_name, $plugin_var_name )) : '';
      }

    } else {

      // Other inputs (text, password, ...)
      if( Params::getParam( $update_param_name ) == 'done' && Params::existParam($param_name)) {
        $val = Params::getParam( $param_name );
      } else {
        $val = ( osc_get_preference( $param_name, $plugin_var_name) != '' ) ? osc_get_preference( $param_name, $plugin_var_name ) : '';
      }
    }


    // If save button was pressed, update param
    if( Params::getParam( $update_param_name ) == 'done' ) {

      if(osc_get_preference( $param_name, $plugin_var_name ) == '') {
        if ($type == 'code') {
          osc_set_preference( $param_name, stripslashes($val), $plugin_var_name, 'STRING');
        } else {
          osc_set_preference( $param_name, $val, $plugin_var_name, 'STRING');  
        }
      } else {
        $dao_preference = new Preference();

        if ($type == 'code') {
          $dao_preference->update( array( "s_value" => stripslashes($val) ), array( "s_section" => $plugin_var_name, "s_name" => $param_name ));
        } else {
          $dao_preference->update( array( "s_value" => $val ), array( "s_section" => $plugin_var_name, "s_name" => $param_name ));
        }

        osc_reset_preferences();
        unset($dao_preference);
      }
    }

    return $val;
  }
}


if(!function_exists('message_ok')) {
  function message_ok( $text ) {
    $final  = '<div class="flashmessage flashmessage-ok flashmessage-inline">';
    $final .= $text;
    $final .= '</div>';
    echo $final;
  }
}


if(!function_exists('message_error')) {
  function message_error( $text ) {
    $final  = '<div class="flashmessage flashmessage-error flashmessage-inline">';
    $final .= $text;
    $final .= '</div>';
    echo $final;
  }
}


if( !function_exists('osc_is_contact_page') ) {
  function osc_is_contact_page() {
    $location = Rewrite::newInstance()->get_location();
    $section = Rewrite::newInstance()->get_section();
    if( $location == 'contact' ) {
      return true ;
    }

    return false ;
  }
}


// COOKIES WORK
if(!function_exists('mb_set_cookie')) {
  function mb_set_cookie($name, $val) {
    Cookie::newInstance()->set_expires( 86400 * 30 );
    Cookie::newInstance()->push($name, $val);
    Cookie::newInstance()->set();
  }
}


if(!function_exists('mb_get_cookie')) {
  function mb_get_cookie($name) {
    return Cookie::newInstance()->get_value($name);
  }
}

if(!function_exists('mb_drop_cookie')) {
  function mb_drop_cookie($name) {
    Cookie::newInstance()->pop($name);
  }
}

?>