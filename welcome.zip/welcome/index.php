<?php
/*
  Plugin Name: Welcome Box Plugin
  Plugin URI: https://osclasspoint.com
  Description: Show welcome pop-up box on home page
  Version: 1.0.1
  Author: MB Themes
  Author URI: https://www.mb-themes.com
  Author Email: info@mb-themes.com
  Short Name: welcome
  Plugin update URI: welcome
  Support URI: https://forums.mb-themes.com/welcome-box-plugin/
  Product Key: 9BgL1gFtkfYIx0KVQJ58
*/



osc_enqueue_style('wlc-user-style', osc_base_url() . 'oc-content/plugins/welcome/css/user.css');

require_once 'functions.php';


function wlc_home_footer() {
  $actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

  if(strpos($actual_link, osc_admin_base_url()) !== false) {
    return false;
  }

  $version = osc_get_preference('version', 'plugin-welcome');
  $user_type = osc_get_preference('user_type', 'plugin-welcome');
  $dev_mode = osc_get_preference('dev_mode', 'plugin-welcome');

  if(mb_get_cookie('wlc_shown_v' . $version) <> 1) {
    mb_set_cookie('wlc_shown_v' . $version, 1);
  } else {
    if($dev_mode <> 1) {
      return false;
    }
  }

  if(osc_get_preference('enabled', 'plugin-welcome') <> 1) {
    return false;
  }



  if(osc_is_home_page()) {
    if($user_type == 0 || ($user_type == 1 && !osc_is_web_user_logged_in()) || ($user_type == 2 && osc_is_web_user_logged_in()) || ($user_type == 3  && osc_is_admin_user_logged_in())) {
      require_once 'user/box.php';
    }
  }
}

osc_add_hook('footer', 'wlc_home_footer', 2);


// ADD SCRIPT TO FOOTER
function wlc_footer_script() { 
  ?>
    <script>
      $(document).ready(function(){
        $('body').on('click', '#wlc-cover, #wlc-close', function(e){
          $('#wlc-cover, #wlc-box').fadeOut(200);
        });
      });
    </script>
  <?php
}

osc_add_hook('footer', 'wlc_footer_script');


// INSTALL FUNCTION - DEFINE VARIABLES
function wlc_call_after_install() {
  osc_set_preference('enabled', 1, 'plugin-welcome', 'INTEGER');
  osc_set_preference('dev_mode', 1, 'plugin-welcome', 'INTEGER');
  osc_set_preference('user_type', 0, 'plugin-welcome', 'INTEGER');
  osc_set_preference('version', 1, 'plugin-welcome', 'INTEGER');
  osc_set_preference('support', 1, 'plugin-welcome', 'INTEGER');
  osc_set_preference('html1', '<img src="/oc-content/plugins/welcome/img/celebrate.png"/>', 'plugin-welcome', 'STRING');
  osc_set_preference('html2', 'Enjoy discounts now!', 'plugin-welcome', 'STRING');
  osc_set_preference('html3', 'We have prepared better promotions for you. Highlight and republish your listings easily.', 'plugin-welcome', 'STRING');
  osc_set_preference('html4', 'Recently our classifieds were redeveloped and as result we brought to you easy listing share, highlights, premiums, moving to top and credit packs as well. Enjoy these benefits and sell your items much faster than before.', 'plugin-welcome', 'STRING');
  osc_set_preference('html5', '<a href="https://osclasspoint.com">Discover OsclassPoint Market</a>', 'plugin-welcome', 'STRING');
}


function wlc_call_after_uninstall() {
  osc_delete_preference('enabled', 'plugin-welcome');
  osc_delete_preference('dev_mode', 'plugin-welcome');
  osc_delete_preference('user_type', 'plugin-welcome');
  osc_delete_preference('version', 'plugin-welcome');
  osc_delete_preference('support', 'plugin-welcome');
  osc_delete_preference('html1', 'plugin-welcome');
  osc_delete_preference('html2', 'plugin-welcome');
  osc_delete_preference('html3', 'plugin-welcome');
  osc_delete_preference('html4', 'plugin-welcome');
  osc_delete_preference('html5', 'plugin-welcome');
}



// ADMIN MENU
function wlc_menu($title = NULL) {
  echo '<link href="' . osc_base_url() . 'oc-content/plugins/welcome/css/admin.css" rel="stylesheet" type="text/css" />';
  echo '<link href="' . osc_base_url() . 'oc-content/plugins/welcome/css/bootstrap-switch.css" rel="stylesheet" type="text/css" />';
  echo '<link href="' . osc_base_url() . 'oc-content/plugins/welcome/css/tipped.css" rel="stylesheet" type="text/css" />';
  echo '<link href="//fonts.googleapis.com/css?family=Open+Sans:300,600&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css" />';
  echo '<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />';
  echo '<script src="' . osc_base_url() . 'oc-content/plugins/welcome/js/admin.js"></script>';
  echo '<script src="' . osc_base_url() . 'oc-content/plugins/welcome/js/tipped.js"></script>';
  echo '<script src="' . osc_base_url() . 'oc-content/plugins/welcome/js/bootstrap-switch.js"></script>';



  if( $title == '') { $title = __('Configure', 'welcome'); }

  $text  = '<div class="mb-head">';
  $text .= '<div class="mb-head-left">';
  $text .= '<h1>' . $title . '</h1>';
  $text .= '<h2>Welcome Box Plugin</h2>';
  $text .= '</div>';
  $text .= '<div class="mb-head-right">';
  $text .= '<ul class="mb-menu">';
  $text .= '<li><a href="' . osc_base_url() . 'oc-admin/index.php?page=plugins&action=renderplugin&file=welcome/admin/configure.php"><i class="fa fa-wrench"></i><span>' . __('Configure', 'welcome') . '</span></a></li>';
  $text .= '</ul>';
  $text .= '</div>';
  $text .= '</div>';

  echo $text;
}



// ADMIN FOOTER
function wlc_footer() {
  $pluginInfo = osc_plugin_get_info('welcome/index.php');
  $text  = '<div class="mb-footer">';
  $text .= '<a target="_blank" class="mb-developer" href="https://mb-themes.com"><img src="https://mb-themes.com/favicon.ico" alt="MB Themes" /> MB-Themes.com</a>';
  $text .= '<a target="_blank" href="' . $pluginInfo['support_uri'] . '"><i class="fa fa-bug"></i> ' . __('Report Bug', 'welcome') . '</a>';
  $text .= '<a target="_blank" href="https://forums.mb-themes.com/"><i class="fa fa-handshake-o"></i> ' . __('Support Forums', 'welcome') . '</a>';
  $text .= '<a target="_blank" class="mb-last" href="mailto:info@mb-themes.com"><i class="fa fa-envelope"></i> ' . __('Contact Us', 'welcome') . '</a>';
  $text .= '<span class="mb-version">v' . $pluginInfo['version'] . '</span>';
  $text .= '</div>';

  return $text;
}



// ADD MENU LINK TO PLUGIN LIST
function wlc_admin_menu() {
echo '<h3><a href="#">Welcome Box Plugin</a></h3>
<ul> 
  <li><a style="color:#2eacce;" href="' . osc_admin_render_plugin_url(osc_plugin_path(dirname(__FILE__)) . '/admin/configure.php') . '">&raquo; ' . __('Configure', 'welcome') . '</a></li>
</ul>';
}


// ADD MENU TO PLUGINS MENU LIST
osc_add_hook('admin_menu','wlc_admin_menu', 1);



// DISPLAY CONFIGURE LINK IN LIST OF PLUGINS
function wlc_conf() {
  osc_admin_render_plugin( osc_plugin_path( dirname(__FILE__) ) . '/admin/configure.php' );
}

osc_add_hook( osc_plugin_path( __FILE__ ) . '_configure', 'wlc_conf' );	


// CALL WHEN PLUGIN IS ACTIVATED - INSTALLED
osc_register_plugin(osc_plugin_path(__FILE__), 'wlc_call_after_install');

// SHOW UNINSTALL LINK
osc_add_hook(osc_plugin_path(__FILE__) . '_uninstall', 'wlc_call_after_uninstall');

?>