<?php
  $html1 = trim(osc_get_preference('html1', 'plugin-welcome'));
  $html2 = trim(osc_get_preference('html2', 'plugin-welcome'));
  $html3 = trim(osc_get_preference('html3', 'plugin-welcome'));
  $html4 = trim(osc_get_preference('html4', 'plugin-welcome'));
  $html5 = trim(osc_get_preference('html5', 'plugin-welcome'));
?>

<div id="wlc-box">
  <div id="wlc-close"><i class="fa fa-times"></i></div>

  <div class="inside">
    <?php if($html1 <> '') { ?><div class="row html1"><?php echo $html1; ?></div><?php } ?>
    <?php if($html2 <> '') { ?><div class="row html2"><?php echo $html2; ?></div><?php } ?>
    <?php if($html3 <> '') { ?><div class="row html3"><?php echo $html3; ?></div><?php } ?>
    <?php if($html4 <> '') { ?><div class="row html4"><?php echo $html4; ?></div><?php } ?>
    <?php if($html5 <> '') { ?><div class="row html5"><?php echo $html5; ?></div><?php } ?>
  </div>
</div>

<div id="wlc-cover">&nbsp;</div>