<?php if( isset($detail['s_id']) && !empty($detail['s_id']) ) { ?>
<style>
.embed-box {
    position: relative;
    padding-bottom: 62.25%; /* ratio for youtube embed */
    padding-top: 30px;
    height: auto;
    overflow: hidden;
}
.embed-box iframe,
.embed-box object,
.embed-box embed {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}
</style>
<div>
    <h2 style="margin-top: 10px;"><?php _e('Youtube video', 'youtube') ; ?></h2>
    <div class="embed-box">
    <iframe type="text/html" src="https://www.youtube.com/embed/<?php echo $detail['s_id']; ?>" frameborder="0" allowfullscreen></iframe>
    </div>
</div>
<?php } ?>